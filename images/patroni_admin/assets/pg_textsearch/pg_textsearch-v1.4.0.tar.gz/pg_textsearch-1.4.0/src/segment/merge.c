/*
 * Copyright (c) 2025-2026 Tiger Data, Inc.
 * Licensed under the PostgreSQL License. See LICENSE for details.
 *
 * merge.c - Segment merge for LSM-style compaction
 */
#include <postgres.h>

#include <access/generic_xlog.h>
#include <access/relation.h>
#include <miscadmin.h>
#include <storage/bufmgr.h>
#include <storage/indexfsm.h>
#include <utils/memutils.h>
#include <utils/timestamp.h>

#include "access/am.h"
#include "constants.h"
#include "index/metapage.h"
#include "index/state.h"
#include "segment/alive_bitset.h"
#include "segment/compression.h"
#include "segment/dictionary.h"
#include "segment/docmap.h"
#include "segment/fieldnorm.h"
#include "segment/io.h"
#include "segment/merge.h"
#include "segment/merge_internal.h"
#include "segment/pagemapper.h"
#include "segment/segment.h"
#include "segment/tombstone.h"

/* Sentinel for dead docs in old_to_new mapping */
#define TP_MERGE_DOC_DEAD UINT32_MAX

/* GUC variable for segment compression */
extern bool tp_compress_segments;

/*
 * Types TpMergeSource, TpTermSegmentRef, TpMergedTerm,
 * TpMergePostingInfo, TpPostingMergeSource, TpMergeDocMapping,
 * and MergeTermBlockInfo are defined in merge_internal.h.
 */

/* ----------------------------------------------------------------
 * Merge sink: paged I/O abstraction
 * ----------------------------------------------------------------
 */

void
merge_sink_init_pages(TpMergeSink *sink, Relation index)
{
	memset(sink, 0, sizeof(TpMergeSink));
	sink->index = index;
	tp_segment_writer_init(&sink->writer, index);
	sink->current_offset = sink->writer.current_offset;
}

/*
 * Sequential append to sink.
 */
static void
merge_sink_write(TpMergeSink *sink, const void *data, Size size)
{
	tp_segment_writer_write(&sink->writer, data, size);
	sink->current_offset = sink->writer.current_offset;
}

/*
 * Positioned write for backpatching (dict entries, header).
 *
 * Each per-page chunk is logged as a small GenericXLog delta against the
 * page that the writer flush already wrote.  This keeps backpatch WAL
 * traffic proportional to the number of bytes actually changed (a few
 * dict entries or the segment header struct), rather than emitting a
 * full-page image for every visited page.
 */
static void
merge_sink_write_at(
		TpMergeSink *sink, uint64 offset, const void *data, uint32 size)
{
	const char *src		  = (const char *)data;
	uint32		remaining = size;
	uint64		pos		  = offset;

	while (remaining > 0)
	{
		uint32			  logical_pg = tp_logical_page(pos);
		uint32			  pg_off	 = tp_page_offset(pos);
		uint32			  avail		 = SEGMENT_DATA_PER_PAGE - pg_off;
		uint32			  chunk		 = Min(remaining, avail);
		BlockNumber		  physical_block;
		Buffer			  buf;
		Page			  page;
		GenericXLogState *xlog_state;

		Assert(logical_pg < sink->writer.pages_allocated);
		physical_block = sink->writer.pages[logical_pg];

		buf = ReadBuffer(sink->index, physical_block);
		LockBuffer(buf, BUFFER_LOCK_EXCLUSIVE);
		xlog_state = GenericXLogStart(sink->index);
		page	   = GenericXLogRegisterBuffer(xlog_state, buf, 0);
		memcpy((char *)page + SizeOfPageHeaderData + pg_off, src, chunk);
		GenericXLogFinish(xlog_state);
		UnlockReleaseBuffer(buf);

		src += chunk;
		pos += chunk;
		remaining -= chunk;
	}
}

/* ----------------------------------------------------------------
 * Merge source operations
 * ----------------------------------------------------------------
 */

/*
 * Advance a merge source to its next term.
 * Returns false if source is exhausted.
 */
bool
merge_source_advance(TpMergeSource *source)
{
	TpSegmentHeader *header;

	if (source->exhausted)
		return false;

	/* Free previous term if any */
	if (source->current_term)
	{
		pfree(source->current_term);
		source->current_term = NULL;
	}

	source->current_idx++;

	if (source->current_idx >= source->num_terms)
	{
		source->exhausted = true;
		return false;
	}

	header = source->reader->header;

	/* Read the term at current index */
	source->current_term = tp_segment_read_term_at_index(
			source->reader,
			source->reader->header,
			source->string_offsets,
			source->current_idx);

	/* Read the dictionary entry (version-aware) */
	tp_segment_read_dict_entry(
			source->reader,
			header,
			source->current_idx,
			&source->current_entry);

	return true;
}

/*
 * Initialize a merge source for a segment.
 * Returns false if segment is empty or invalid.
 */
bool
merge_source_init(TpMergeSource *source, Relation index, BlockNumber root)
{
	TpSegmentHeader *header;
	TpDictionary	 dict_header;

	memset(source, 0, sizeof(TpMergeSource));
	source->exhausted = true; /* Assume failure */

	source->reader = tp_segment_open(index, root);
	if (!source->reader)
		return false;

	header = source->reader->header;

	if (header->num_terms == 0)
	{
		tp_segment_close(source->reader);
		source->reader = NULL;
		return false;
	}

	source->num_terms = header->num_terms;

	/* Read dictionary header */
	tp_segment_read(
			source->reader,
			header->dictionary_offset,
			&dict_header,
			sizeof(dict_header.num_terms));

	/* Cache all string offsets for this segment */
	source->string_offsets = palloc_extended(
			sizeof(uint32) * source->num_terms, MCXT_ALLOC_HUGE);
	tp_segment_read(
			source->reader,
			header->dictionary_offset + sizeof(dict_header.num_terms),
			source->string_offsets,
			sizeof(uint32) * source->num_terms);

	/* Position before first term (advance will move to index 0) */
	source->current_idx	 = UINT32_MAX; /* Will wrap to 0 on advance */
	source->exhausted	 = false;
	source->current_term = NULL;

	/* Advance to first term */
	if (!merge_source_advance(source))
	{
		tp_segment_close(source->reader);
		source->reader = NULL;
		pfree(source->string_offsets);
		source->string_offsets = NULL;
		return false;
	}

	return true;
}

/*
 * Initialize a merge source from a pre-opened reader.
 * Same as merge_source_init but takes a TpSegmentReader directly.
 * Does NOT close the reader on failure (caller owns it).
 */
bool
merge_source_init_from_reader(TpMergeSource *source, TpSegmentReader *reader)
{
	TpSegmentHeader *header;
	TpDictionary	 dict_header;

	memset(source, 0, sizeof(TpMergeSource));
	source->exhausted = true; /* Assume failure */

	if (!reader)
		return false;

	source->reader = reader;
	header		   = reader->header;

	if (header->num_terms == 0)
		return false;

	source->num_terms = header->num_terms;

	/* Read dictionary header */
	tp_segment_read(
			source->reader,
			header->dictionary_offset,
			&dict_header,
			sizeof(dict_header.num_terms));

	/* Cache all string offsets for this segment */
	source->string_offsets = palloc_extended(
			sizeof(uint32) * source->num_terms, MCXT_ALLOC_HUGE);
	tp_segment_read(
			source->reader,
			header->dictionary_offset + sizeof(dict_header.num_terms),
			source->string_offsets,
			sizeof(uint32) * source->num_terms);

	/* Position before first term */
	source->current_idx	 = UINT32_MAX;
	source->exhausted	 = false;
	source->current_term = NULL;

	/* Advance to first term */
	if (!merge_source_advance(source))
	{
		pfree(source->string_offsets);
		source->string_offsets = NULL;
		source->reader		   = NULL; /* Don't close, caller owns it */
		return false;
	}

	return true;
}

/*
 * Close and cleanup a merge source.
 */
void
merge_source_close(TpMergeSource *source)
{
	if (source->current_term)
	{
		pfree(source->current_term);
		source->current_term = NULL;
	}
	if (source->string_offsets)
	{
		pfree(source->string_offsets);
		source->string_offsets = NULL;
	}
	if (source->reader)
	{
		tp_segment_close(source->reader);
		source->reader = NULL;
	}
}

/*
 * Find the source with the lexicographically smallest current term.
 * Returns -1 if all sources are exhausted.
 */
int
merge_find_min_source(TpMergeSource *sources, int num_sources)
{
	int			min_idx	 = -1;
	const char *min_term = NULL;
	int			i;

	for (i = 0; i < num_sources; i++)
	{
		if (sources[i].exhausted)
			continue;

		if (min_idx < 0 || strcmp(sources[i].current_term, min_term) < 0)
		{
			min_idx	 = i;
			min_term = sources[i].current_term;
		}
	}

	return min_idx;
}

/*
 * Add a segment reference to a merged term.
 * This records which segment has this term, without loading postings.
 */
void
merged_term_add_segment_ref(
		TpMergedTerm *term, int segment_idx, TpDictEntry *entry)
{
	/* Grow array if needed */
	if (term->num_segment_refs >= term->segment_refs_capacity)
	{
		uint32 new_capacity = term->segment_refs_capacity == 0
									? 8
									: term->segment_refs_capacity * 2;
		if (term->segment_refs == NULL)
			term->segment_refs = palloc(
					new_capacity * sizeof(TpTermSegmentRef));
		else
			term->segment_refs = repalloc(
					term->segment_refs,
					new_capacity * sizeof(TpTermSegmentRef));
		term->segment_refs_capacity = new_capacity;
	}

	term->segment_refs[term->num_segment_refs].segment_idx = segment_idx;
	term->segment_refs[term->num_segment_refs].entry	   = *entry;
	term->num_segment_refs++;
}

/*
 * Load the next block of postings for merge source.
 * Returns true if a block was loaded, false if no more blocks remain.
 */
static bool
posting_source_load_block(TpPostingMergeSource *ps)
{
	if (ps->current_block >= ps->block_count)
		return false;

	/* Read skip entry for current block (version-aware) */
	tp_segment_read_skip_entry(
			ps->reader,
			ps->skip_index_offset,
			ps->current_block,
			&ps->skip_entry);

	/*
	 * Ensure we have enough buffer space. We reuse the buffer between blocks,
	 * only reallocating when a larger block is encountered. Old block data is
	 * no longer needed since we process blocks sequentially.
	 *
	 * The NULL check ensures allocation on first call (when block_postings is
	 * uninitialized) even if doc_count happens to equal block_capacity.
	 */
	if (ps->block_postings == NULL ||
		ps->skip_entry.doc_count > ps->block_capacity)
	{
		if (ps->block_postings)
			pfree(ps->block_postings);
		ps->block_postings = palloc(
				ps->skip_entry.doc_count * sizeof(TpBlockPosting));
		ps->block_capacity = ps->skip_entry.doc_count;
	}

	/* Read posting data for this block (handle compression) */
	if (ps->skip_entry.flags == TP_BLOCK_FLAG_DELTA)
	{
		/* Compressed block - read and decompress */
		uint8 compressed_buf[TP_MAX_COMPRESSED_BLOCK_SIZE];

		tp_segment_read(
				ps->reader,
				ps->skip_entry.posting_offset,
				compressed_buf,
				TP_MAX_COMPRESSED_BLOCK_SIZE);

		tp_decompress_block(
				compressed_buf,
				ps->skip_entry.doc_count,
				0, /* first_doc_id - deltas are relative within block */
				ps->block_postings);
	}
	else
	{
		/* Uncompressed block - read directly */
		tp_segment_read(
				ps->reader,
				ps->skip_entry.posting_offset,
				ps->block_postings,
				ps->skip_entry.doc_count * sizeof(TpBlockPosting));
	}

	ps->current_in_block = 0;
	return true;
}

/*
 * Convert current block posting to output format.
 */
static void
posting_source_convert_current(TpPostingMergeSource *ps)
{
	TpBlockPosting *bp = &ps->block_postings[ps->current_in_block];
	BlockNumber		page;
	OffsetNumber	offset;

	/*
	 * Look up CTID from split arrays (needed for N-way merge ordering).
	 * Use cached arrays if available, otherwise read from segment.
	 */
	if (ps->reader->cached_ctid_pages != NULL &&
		bp->doc_id < ps->reader->cached_num_docs)
	{
		page   = ps->reader->cached_ctid_pages[bp->doc_id];
		offset = ps->reader->cached_ctid_offsets[bp->doc_id];
	}
	else
	{
		TpSegmentHeader *header = ps->reader->header;

		tp_segment_read(
				ps->reader,
				header->ctid_pages_offset + (bp->doc_id * sizeof(BlockNumber)),
				&page,
				sizeof(BlockNumber));
		tp_segment_read(
				ps->reader,
				header->ctid_offsets_offset +
						(bp->doc_id * sizeof(OffsetNumber)),
				&offset,
				sizeof(OffsetNumber));
	}

	/* Build output posting info */
	ItemPointerSet(&ps->current.ctid, page, offset);
	ps->current.old_doc_id = bp->doc_id;
	ps->current.frequency  = bp->frequency;
	ps->current.fieldnorm  = bp->fieldnorm;
}

/*
 * Initialize a posting merge source for streaming.
 */
void
posting_source_init(
		TpPostingMergeSource *ps, TpSegmentReader *reader, TpDictEntry *entry)
{
	memset(ps, 0, sizeof(TpPostingMergeSource));
	ps->reader			  = reader;
	ps->skip_index_offset = entry->skip_index_offset;
	ps->block_count		  = entry->block_count;
	ps->current_block	  = 0;
	ps->current_in_block  = 0;
	ps->block_postings	  = NULL;
	ps->block_capacity	  = 0;
	ps->exhausted		  = (entry->block_count == 0);

	if (!ps->exhausted)
	{
		if (posting_source_load_block(ps))
		{
			posting_source_convert_current(ps);
		}
		else
		{
			ps->exhausted = true;
		}
	}
}

/*
 * Initialize a posting merge source for fast streaming (disjoint mode).
 * Skips posting_source_convert_current since CTID lookups are not needed.
 */
void
posting_source_init_fast(
		TpPostingMergeSource *ps, TpSegmentReader *reader, TpDictEntry *entry)
{
	memset(ps, 0, sizeof(TpPostingMergeSource));
	ps->reader			  = reader;
	ps->skip_index_offset = entry->skip_index_offset;
	ps->block_count		  = entry->block_count;
	ps->current_block	  = 0;
	ps->current_in_block  = 0;
	ps->block_postings	  = NULL;
	ps->block_capacity	  = 0;
	ps->exhausted		  = (entry->block_count == 0);

	if (!ps->exhausted)
	{
		if (!posting_source_load_block(ps))
			ps->exhausted = true;
	}
}

/*
 * Free posting merge source resources.
 */
void
posting_source_free(TpPostingMergeSource *ps)
{
	if (ps->block_postings)
	{
		pfree(ps->block_postings);
		ps->block_postings = NULL;
	}
}

/*
 * Advance a posting merge source to the next posting.
 */
bool
posting_source_advance(TpPostingMergeSource *ps)
{
	if (ps->exhausted)
		return false;

	ps->current_in_block++;

	/* Move to next block if current exhausted */
	while (ps->current_in_block >= ps->skip_entry.doc_count)
	{
		ps->current_block++;
		if (ps->current_block >= ps->block_count)
		{
			ps->exhausted = true;
			return false;
		}
		if (!posting_source_load_block(ps))
		{
			ps->exhausted = true;
			return false;
		}
	}

	posting_source_convert_current(ps);
	return true;
}

/*
 * Advance a posting merge source without CTID conversion (disjoint mode).
 * Reads doc_id, frequency, fieldnorm directly from the block posting
 * array, skipping the expensive CTID lookups in convert_current.
 */
bool
posting_source_advance_fast(TpPostingMergeSource *ps)
{
	if (ps->exhausted)
		return false;

	ps->current_in_block++;

	/* Move to next block if current exhausted */
	while (ps->current_in_block >= ps->skip_entry.doc_count)
	{
		ps->current_block++;
		if (ps->current_block >= ps->block_count)
		{
			ps->exhausted = true;
			return false;
		}
		if (!posting_source_load_block(ps))
		{
			ps->exhausted = true;
			return false;
		}
	}

	return true;
}

/*
 * Find the posting source with the smallest current CTID.
 * Returns -1 if all sources are exhausted.
 */
int
find_min_posting_source(TpPostingMergeSource *sources, int num_sources)
{
	int				min_idx = -1;
	ItemPointerData min_ctid;
	int				i;

	for (i = 0; i < num_sources; i++)
	{
		ItemPointerData ctid;

		if (sources[i].exhausted)
			continue;

		/* Copy to avoid unaligned access from packed struct */
		memcpy(&ctid, &sources[i].current.ctid, sizeof(ItemPointerData));

		if (min_idx < 0 || ItemPointerCompare(&ctid, &min_ctid) < 0)
		{
			min_idx = i;
			memcpy(&min_ctid, &ctid, sizeof(ItemPointerData));
		}
	}

	return min_idx;
}

/* TpMergeDocMapping is defined in merge_internal.h */

/*
 * Per-source state for the streaming N-way merge of docmaps.
 */
typedef struct TpDocmapMergeSource
{
	BlockNumber	 *ctid_pages;	/* CTID page numbers (4 bytes/doc) */
	OffsetNumber *ctid_offsets; /* CTID tuple offsets (2 bytes/doc) */
	uint8		 *fieldnorms;	/* Encoded fieldnorms (1 byte/doc) */
	uint32		  num_docs;		/* Total docs in this source */
	uint32		  cursor;		/* Current position in arrays */
	bool		  owns_arrays;	/* True if we allocated the arrays */
} TpDocmapMergeSource;

/*
 * Build merged docmap using streaming N-way merge of sorted CTID arrays.
 * Also builds direct mapping arrays for fast old->new doc_id lookup.
 *
 * Each source segment maintains the invariant that doc_ids are in CTID
 * order. An N-way merge of these sorted streams produces the global
 * CTID order without needing a hash table, reducing memory from ~5.5GB
 * to ~2.5GB for 138M documents across 24 segments.
 */
TpDocMapBuilder *
build_merged_docmap(
		TpMergeSource	  *sources,
		int				   num_sources,
		TpMergeDocMapping *mapping,
		bool			   disjoint_sources)
{
	TpDocMapBuilder		*docmap;
	TpDocmapMergeSource *msources;
	uint32				 total_docs = 0;
	BlockNumber			*out_pages;
	OffsetNumber		*out_offsets;
	uint8				*out_fieldnorms;
	uint32				 new_doc_id = 0;
	int					 i;

	/* Initialize mapping arrays */
	mapping->num_sources = num_sources;
	mapping->old_to_new	 = (uint32 **)palloc0(num_sources * sizeof(uint32 *));

	/*
	 * Step 1: Load source CTID and fieldnorm arrays.
	 * Reuse the reader's cached arrays when available to avoid
	 * redundant copies.
	 */
	msources = palloc0(num_sources * sizeof(TpDocmapMergeSource));
	for (i = 0; i < num_sources; i++)
	{
		TpSegmentHeader		*header = sources[i].reader->header;
		TpDocmapMergeSource *ms		= &msources[i];

		ms->num_docs = header->num_docs;
		ms->cursor	 = 0;

		if (ms->num_docs == 0 || header->ctid_pages_offset == 0)
		{
			ms->num_docs = 0; /* Exclude from N-way merge */
			continue;
		}

		total_docs += ms->num_docs;
		mapping->old_to_new[i] = palloc_extended(
				ms->num_docs * sizeof(uint32), MCXT_ALLOC_HUGE);

		/* CTID arrays: use cached if available, else bulk-read */
		if (sources[i].reader->cached_ctid_pages != NULL)
		{
			ms->ctid_pages	 = sources[i].reader->cached_ctid_pages;
			ms->ctid_offsets = sources[i].reader->cached_ctid_offsets;
			ms->owns_arrays	 = false;
		}
		else
		{
			ms->ctid_pages = palloc_extended(
					ms->num_docs * sizeof(BlockNumber), MCXT_ALLOC_HUGE);
			tp_segment_read(
					sources[i].reader,
					header->ctid_pages_offset,
					ms->ctid_pages,
					ms->num_docs * sizeof(BlockNumber));

			ms->ctid_offsets = palloc_extended(
					ms->num_docs * sizeof(OffsetNumber), MCXT_ALLOC_HUGE);
			tp_segment_read(
					sources[i].reader,
					header->ctid_offsets_offset,
					ms->ctid_offsets,
					ms->num_docs * sizeof(OffsetNumber));
			ms->owns_arrays = true;
		}

		/* Fieldnorms: always bulk-read (not cached by reader) */
		ms->fieldnorms =
				palloc_extended(ms->num_docs * sizeof(uint8), MCXT_ALLOC_HUGE);
		tp_segment_read(
				sources[i].reader,
				header->fieldnorm_offset,
				ms->fieldnorms,
				ms->num_docs * sizeof(uint8));
	}

	/* Step 2: Allocate output arrays (palloc(0) is valid in PG) */
	out_pages =
			palloc_extended(total_docs * sizeof(BlockNumber), MCXT_ALLOC_HUGE);
	out_offsets = palloc_extended(
			total_docs * sizeof(OffsetNumber), MCXT_ALLOC_HUGE);
	out_fieldnorms =
			palloc_extended(total_docs * sizeof(uint8), MCXT_ALLOC_HUGE);

	/*
	 * Step 3: Merge docmaps.
	 *
	 * When disjoint_sources is true, sources have non-overlapping
	 * CTID ranges in source order, so we concatenate sequentially
	 * instead of doing an N-way comparison. This eliminates the
	 * per-doc CTID comparison overhead.
	 */
	if (disjoint_sources)
	{
		for (i = 0; i < num_sources; i++)
		{
			TpDocmapMergeSource *ms = &msources[i];
			uint32				 j;

			for (j = 0; j < ms->num_docs; j++)
			{
				if (!tp_segment_is_alive(sources[i].reader, j))
				{
					mapping->old_to_new[i][j] = TP_MERGE_DOC_DEAD;
					continue;
				}
				mapping->old_to_new[i][j]  = new_doc_id;
				out_pages[new_doc_id]	   = ms->ctid_pages[j];
				out_offsets[new_doc_id]	   = ms->ctid_offsets[j];
				out_fieldnorms[new_doc_id] = ms->fieldnorms[j];
				new_doc_id++;
			}
		}
	}
	else
	{
		/*
		 * N-way merge: each source's docs are already in CTID
		 * order. Find the source with smallest current CTID via
		 * linear scan (N is small, typically <= 24).
		 */
		while (new_doc_id < total_docs)
		{
			int			 min_src	= -1;
			BlockNumber	 min_page	= 0;
			OffsetNumber min_offset = 0;

			for (i = 0; i < num_sources; i++)
			{
				TpDocmapMergeSource *ms = &msources[i];
				BlockNumber			 pg;
				OffsetNumber		 off;

				/* Skip past dead docs */
				while (ms->cursor < ms->num_docs &&
					   !tp_segment_is_alive(sources[i].reader, ms->cursor))
				{
					mapping->old_to_new[i][ms->cursor] = TP_MERGE_DOC_DEAD;
					ms->cursor++;
				}

				if (ms->cursor >= ms->num_docs)
					continue;

				pg	= ms->ctid_pages[ms->cursor];
				off = ms->ctid_offsets[ms->cursor];

				if (min_src < 0 || pg < min_page ||
					(pg == min_page && off < min_offset))
				{
					min_src	   = i;
					min_page   = pg;
					min_offset = off;
				}
			}

			if (min_src < 0)
				break; /* All sources exhausted */

			{
				TpDocmapMergeSource *ms	 = &msources[min_src];
				uint32				 pos = ms->cursor;

				mapping->old_to_new[min_src][pos] = new_doc_id;
				out_pages[new_doc_id]			  = ms->ctid_pages[pos];
				out_offsets[new_doc_id]			  = ms->ctid_offsets[pos];
				out_fieldnorms[new_doc_id]		  = ms->fieldnorms[pos];
				ms->cursor++;
			}
			new_doc_id++;
		}
	}

	/* Step 4: Package into a TpDocMapBuilder (finalized, no hash table) */
	docmap				 = palloc0(sizeof(TpDocMapBuilder));
	docmap->ctid_to_id	 = NULL; /* No hash table needed */
	docmap->num_docs	 = new_doc_id;
	docmap->capacity	 = new_doc_id;
	docmap->finalized	 = true;
	docmap->ctid_pages	 = out_pages;
	docmap->ctid_offsets = out_offsets;
	docmap->fieldnorms	 = out_fieldnorms;

	/*
	 * Compute merged total_tokens as Σ source.header.total_tokens
	 * minus a fieldnorm-decoded approximation of dead-doc tokens.
	 * For all-live sources the result is exact (matches the raw sum
	 * maintained by the spill and build-context paths); for sources
	 * with some dead docs the quantization error is bounded by the
	 * dead contribution only, not by the whole segment.
	 */
	{
		uint64 merged_total_tokens = 0;

		for (i = 0; i < num_sources; i++)
		{
			TpDocmapMergeSource *ms = &msources[i];
			uint64 src_total		= sources[i].reader->header->total_tokens;
			uint64 dead_tokens		= 0;

			for (uint32 d = 0; d < ms->num_docs; d++)
			{
				if (!tp_segment_is_alive(sources[i].reader, d))
					dead_tokens += decode_fieldnorm(ms->fieldnorms[d]);
			}
			merged_total_tokens += (src_total > dead_tokens)
										 ? (src_total - dead_tokens)
										 : 0;
		}
		docmap->total_tokens = merged_total_tokens;
	}

	/* Free per-source arrays we allocated */
	for (i = 0; i < num_sources; i++)
	{
		if (msources[i].owns_arrays)
		{
			pfree(msources[i].ctid_pages);
			pfree(msources[i].ctid_offsets);
		}
		if (msources[i].fieldnorms)
			pfree(msources[i].fieldnorms);
	}
	pfree(msources);

	return docmap;
}

/*
 * Free merge doc mapping arrays.
 */
void
free_merge_doc_mapping(TpMergeDocMapping *mapping)
{
	int i;

	for (i = 0; i < mapping->num_sources; i++)
	{
		if (mapping->old_to_new[i])
			pfree(mapping->old_to_new[i]);
	}
	pfree((void *)mapping->old_to_new);
}

/*
 * Initialize N-way merge posting sources for a term.
 * Returns the number of sources initialized.
 */
TpPostingMergeSource *
init_term_posting_sources(
		TpMergedTerm *term, TpMergeSource *sources, int *num_psources)
{
	TpPostingMergeSource *psources;
	uint32				  i;

	*num_psources = term->num_segment_refs;
	psources = palloc(sizeof(TpPostingMergeSource) * term->num_segment_refs);

	for (i = 0; i < term->num_segment_refs; i++)
	{
		TpTermSegmentRef *ref	 = &term->segment_refs[i];
		TpMergeSource	 *source = &sources[ref->segment_idx];

		posting_source_init(&psources[i], source->reader, &ref->entry);
	}

	return psources;
}

/*
 * Initialize posting sources in fast/disjoint mode (no CTID conversion).
 */
TpPostingMergeSource *
init_term_posting_sources_fast(
		TpMergedTerm *term, TpMergeSource *sources, int *num_psources)
{
	TpPostingMergeSource *psources;
	uint32				  i;

	*num_psources = term->num_segment_refs;
	psources = palloc(sizeof(TpPostingMergeSource) * term->num_segment_refs);

	for (i = 0; i < term->num_segment_refs; i++)
	{
		TpTermSegmentRef *ref	 = &term->segment_refs[i];
		TpMergeSource	 *source = &sources[ref->segment_idx];

		posting_source_init_fast(&psources[i], source->reader, &ref->entry);
	}

	return psources;
}

/*
 * Free N-way merge posting sources for a term.
 */
static void
free_term_posting_sources(TpPostingMergeSource *psources, int num_psources)
{
	int i;

	for (i = 0; i < num_psources; i++)
		posting_source_free(&psources[i]);
	pfree(psources);
}

/* MergeTermBlockInfo is defined in merge_internal.h */

/* ----------------------------------------------------------------
 * Unified merged segment writer
 * ----------------------------------------------------------------
 */

/*
 * Write a merged segment to pages via sink.
 *
 * Layout: [header] -> [dictionary] -> [postings] -> [skip index] ->
 *         [fieldnorm] -> [ctid map]
 *
 * Also writes page index and backpatches header with
 * num_pages/page_index. Caller reads sink->writer.pages[0] for root.
 */
void
write_merged_segment_to_sink(
		TpMergeSink	  *sink,
		TpMergedTerm  *terms,
		uint32		   num_terms,
		TpMergeSource *sources,
		int			   num_sources,
		uint32		   target_level,
		uint64		   total_tokens,
		bool		   disjoint_sources)
{
	TpSegmentHeader		header;
	TpDictionary		dict;
	TpDocMapBuilder	   *docmap;
	TpMergeDocMapping	doc_mapping;
	MergeTermBlockInfo *term_blocks;
	uint32			   *string_offsets;
	uint64				string_pos;
	uint32				i;

	/* Accumulated skip entries for all terms */
	TpSkipEntry *all_skip_entries;
	uint32		 skip_entries_count;
	uint32		 skip_entries_capacity;

	if (num_terms == 0)
		return;

	/* Build docmap and direct mapping arrays from source segments */
	docmap = build_merged_docmap(
			sources, num_sources, &doc_mapping, disjoint_sources);

	/*
	 * build_merged_docmap sets docmap->total_tokens from source
	 * header.total_tokens minus dead-doc fieldnorm approximations;
	 * see its comment for the exact-vs-approximate trade-off.  The
	 * caller's total_tokens parameter is ignored.
	 */
	total_tokens = docmap->total_tokens;

	/*
	 * If all docs are dead, nothing to write. Clean up and return.
	 */
	if (docmap->num_docs == 0)
	{
		free_merge_doc_mapping(&doc_mapping);
		tp_docmap_destroy(docmap);
		return;
	}

	/* Prepare header placeholder */
	memset(&header, 0, sizeof(TpSegmentHeader));
	header.magic		= TP_SEGMENT_MAGIC;
	header.version		= TP_SEGMENT_FORMAT_VERSION;
	header.created_at	= GetCurrentTimestamp();
	header.num_pages	= 0;
	header.num_terms	= num_terms;
	header.level		= target_level;
	header.next_segment = InvalidBlockNumber;
	header.num_docs		= docmap->num_docs;
	header.total_tokens = total_tokens;
	header.page_index	= InvalidBlockNumber;

	/* Write placeholder header */
	merge_sink_write(sink, &header, sizeof(TpSegmentHeader));

	/* Dictionary immediately follows header */
	header.dictionary_offset = sink->current_offset;

	/* Write dictionary header */
	memset(&dict, 0, sizeof(dict));
	dict.num_terms = num_terms;
	merge_sink_write(sink, &dict, offsetof(TpDictionary, string_offsets));

	/* Calculate string offsets */
	string_offsets = palloc_extended(
			num_terms * sizeof(uint32), MCXT_ALLOC_HUGE | MCXT_ALLOC_ZERO);
	string_pos = 0;
	for (i = 0; i < num_terms; i++)
	{
		/*
		 * String-pool offsets are stored as uint32 in the segment
		 * format.  Fail loudly before writing rather than silently
		 * wrapping and producing a segment that reads from the wrong
		 * place (issue #432).
		 */
		if (string_pos > PG_UINT32_MAX)
			ereport(ERROR,
					(errcode(ERRCODE_PROGRAM_LIMIT_EXCEEDED),
					 errmsg("pg_textsearch: merged segment string pool "
							"exceeds the %u-byte format limit",
							PG_UINT32_MAX),
					 errhint("The corpus vocabulary is too large for a "
							 "single segment.")));

		string_offsets[i] = (uint32)string_pos;
		string_pos += (uint64)sizeof(uint32) + terms[i].term_len +
					  sizeof(uint32);
	}

	/* Write string offsets array */
	merge_sink_write(sink, string_offsets, num_terms * sizeof(uint32));

	/* Write string pool */
	header.strings_offset = sink->current_offset;
	for (i = 0; i < num_terms; i++)
	{
		uint32 length	   = terms[i].term_len;
		uint32 dict_offset = i * sizeof(TpDictEntry);

		merge_sink_write(sink, &length, sizeof(uint32));
		merge_sink_write(sink, terms[i].term, length);
		merge_sink_write(sink, &dict_offset, sizeof(uint32));
	}

	/* Record entries offset - dict entries written after postings */
	header.entries_offset = sink->current_offset;

	/* Write placeholder dict entries */
	{
		TpDictEntry placeholder;
		memset(&placeholder, 0, sizeof(TpDictEntry));
		for (i = 0; i < num_terms; i++)
			merge_sink_write(sink, &placeholder, sizeof(TpDictEntry));
	}

	/* Postings start here */
	header.postings_offset = sink->current_offset;

	/* Initialize per-term tracking and skip entry accumulator */
	term_blocks = palloc_extended(
			num_terms * sizeof(MergeTermBlockInfo),
			MCXT_ALLOC_HUGE | MCXT_ALLOC_ZERO);

	skip_entries_capacity = 1024;
	skip_entries_count	  = 0;
	all_skip_entries = palloc(skip_entries_capacity * sizeof(TpSkipEntry));

	/*
	 * Helper macro: flush a full or partial block_buf to the sink.
	 * Computes skip entry, optionally compresses, writes data,
	 * and accumulates the skip entry.
	 */
#define FLUSH_BLOCK(block_buf, block_count, num_blocks)                         \
	do                                                                          \
	{                                                                           \
		TpSkipEntry skip_;                                                      \
		uint16		max_tf_	  = 0;                                              \
		uint8		min_norm_ = 255;                                            \
		uint32		last_did_ = 0;                                              \
		uint32		j_;                                                         \
                                                                                \
		for (j_ = 0; j_ < (block_count); j_++)                                  \
		{                                                                       \
			if ((block_buf)[j_].doc_id > last_did_)                             \
				last_did_ = (block_buf)[j_].doc_id;                             \
			if ((block_buf)[j_].frequency > max_tf_)                            \
				max_tf_ = (block_buf)[j_].frequency;                            \
			if ((block_buf)[j_].fieldnorm < min_norm_)                          \
				min_norm_ = (block_buf)[j_].fieldnorm;                          \
		}                                                                       \
                                                                                \
		skip_.last_doc_id	 = last_did_;                                       \
		skip_.doc_count		 = (uint8)(block_count);                            \
		skip_.block_max_tf	 = max_tf_;                                         \
		skip_.block_max_norm = min_norm_;                                       \
		skip_.posting_offset = sink->current_offset;                            \
		memset(skip_.reserved, 0, sizeof(skip_.reserved));                      \
                                                                                \
		if (tp_compress_segments)                                               \
		{                                                                       \
			uint8  cbuf_[TP_MAX_COMPRESSED_BLOCK_SIZE];                         \
			uint32 csize_;                                                      \
                                                                                \
			csize_		= tp_compress_block((block_buf), (block_count), cbuf_); \
			skip_.flags = TP_BLOCK_FLAG_DELTA;                                  \
			merge_sink_write(sink, cbuf_, csize_);                              \
		}                                                                       \
		else                                                                    \
		{                                                                       \
			skip_.flags = TP_BLOCK_FLAG_UNCOMPRESSED;                           \
			merge_sink_write(                                                   \
					sink,                                                       \
					(block_buf),                                                \
					(block_count) * sizeof(TpBlockPosting));                    \
		}                                                                       \
                                                                                \
		if (skip_entries_count >= skip_entries_capacity)                        \
		{                                                                       \
			skip_entries_capacity *= 2;                                         \
			all_skip_entries = repalloc_huge(                                   \
					all_skip_entries,                                           \
					skip_entries_capacity * sizeof(TpSkipEntry));               \
		}                                                                       \
		all_skip_entries[skip_entries_count++] = skip_;                         \
		(num_blocks)++;                                                         \
	} while (0)

	/*
	 * Streaming pass: for each term, stream postings one block at a
	 * time and write immediately.
	 *
	 * When disjoint_sources is true, drain sources sequentially
	 * (source 0 fully, then source 1, etc.) without CTID lookups.
	 * Otherwise, use N-way CTID-comparison merge.
	 */
	for (i = 0; i < num_terms; i++)
	{
		TpPostingMergeSource *psources;
		int					  num_psources;
		TpBlockPosting		  block_buf[TP_BLOCK_SIZE];
		uint32				  block_count = 0;
		uint32				  doc_count	  = 0;
		uint32				  num_blocks  = 0;

		/* Record where this term's postings start */
		term_blocks[i].posting_offset	= sink->current_offset;
		term_blocks[i].skip_entry_start = skip_entries_count;

		if (terms[i].num_segment_refs == 0)
		{
			term_blocks[i].doc_freq	   = 0;
			term_blocks[i].block_count = 0;
			continue;
		}

		if (disjoint_sources)
		{
			/*
			 * Fast path: sequential drain. Sources have disjoint
			 * CTID ranges, so drain source 0, then 1, etc.
			 * Reads doc_id/frequency/fieldnorm directly from
			 * the block posting array, skipping CTID lookups.
			 */
			psources = init_term_posting_sources_fast(
					&terms[i], sources, &num_psources);

			for (int src = 0; src < num_psources; src++)
			{
				while (!psources[src].exhausted)
				{
					TpBlockPosting *bp =
							&psources[src].block_postings
									 [psources[src].current_in_block];
					int	   seg_idx = terms[i].segment_refs[src].segment_idx;
					uint32 new_id =
							doc_mapping.old_to_new[seg_idx][bp->doc_id];

					if (new_id == TP_MERGE_DOC_DEAD)
					{
						posting_source_advance_fast(&psources[src]);
						continue;
					}

					block_buf[block_count].doc_id	 = new_id;
					block_buf[block_count].frequency = bp->frequency;
					block_buf[block_count].fieldnorm = bp->fieldnorm;
					block_buf[block_count].reserved	 = 0;
					block_count++;
					doc_count++;

					posting_source_advance_fast(&psources[src]);

					if (block_count == TP_BLOCK_SIZE)
					{
						FLUSH_BLOCK(block_buf, block_count, num_blocks);
						block_count = 0;
					}
				}
			}
		}
		else
		{
			/*
			 * Standard N-way merge: compare CTIDs across sources.
			 */
			psources = init_term_posting_sources(
					&terms[i], sources, &num_psources);

			while (true)
			{
				int min_idx = find_min_posting_source(psources, num_psources);
				if (min_idx < 0)
					break;

				{
					int src_idx = terms[i].segment_refs[min_idx].segment_idx;
					uint32 old_doc_id = psources[min_idx].current.old_doc_id;
					uint32 new_id =
							doc_mapping.old_to_new[src_idx][old_doc_id];

					if (new_id == TP_MERGE_DOC_DEAD)
					{
						posting_source_advance(&psources[min_idx]);
						continue;
					}

					block_buf[block_count].doc_id = new_id;
					block_buf[block_count].frequency =
							psources[min_idx].current.frequency;
					block_buf[block_count].fieldnorm =
							psources[min_idx].current.fieldnorm;
					block_buf[block_count].reserved = 0;
				}
				block_count++;
				doc_count++;

				posting_source_advance(&psources[min_idx]);

				if (block_count == TP_BLOCK_SIZE)
				{
					FLUSH_BLOCK(block_buf, block_count, num_blocks);
					block_count = 0;
				}
			}
		}

		/* Write final partial block if any */
		if (block_count > 0)
			FLUSH_BLOCK(block_buf, block_count, num_blocks);

		term_blocks[i].doc_freq	   = doc_count;
		term_blocks[i].block_count = num_blocks;

		free_term_posting_sources(psources, num_psources);

		/* Check for interrupt during long merges */
		if ((i % 1000) == 0)
			CHECK_FOR_INTERRUPTS();
	}

#undef FLUSH_BLOCK

	/* Skip index starts here - after all postings */
	header.skip_index_offset = sink->current_offset;

	/* Write all accumulated skip entries */
	if (skip_entries_count > 0)
	{
		merge_sink_write(
				sink,
				all_skip_entries,
				skip_entries_count * sizeof(TpSkipEntry));
	}

	pfree(all_skip_entries);

	/* Write fieldnorm table */
	header.fieldnorm_offset = sink->current_offset;
	if (docmap->num_docs > 0)
	{
		merge_sink_write(
				sink, docmap->fieldnorms, docmap->num_docs * sizeof(uint8));
	}

	/* Write CTID pages array */
	header.ctid_pages_offset = sink->current_offset;
	if (docmap->num_docs > 0)
	{
		merge_sink_write(
				sink,
				docmap->ctid_pages,
				docmap->num_docs * sizeof(BlockNumber));
	}

	/* Write CTID offsets array */
	header.ctid_offsets_offset = sink->current_offset;
	if (docmap->num_docs > 0)
	{
		merge_sink_write(
				sink,
				docmap->ctid_offsets,
				docmap->num_docs * sizeof(OffsetNumber));
	}

	/* Write alive bitset (all alive — dead docs already excluded) */
	header.alive_bitset_offset = sink->current_offset;
	header.alive_count		   = docmap->num_docs;
	if (docmap->num_docs > 0)
	{
		uint32 bitset_size = tp_alive_bitset_size(docmap->num_docs);
		uint8 *bitset_data = palloc(bitset_size);

		tp_alive_bitset_init_data(bitset_data, docmap->num_docs);
		merge_sink_write(sink, bitset_data, bitset_size);
		pfree(bitset_data);
	}

	/* Finalize data_size */
	header.data_size = sink->current_offset;

	/* Flush writer and write page index */
	{
		BlockNumber page_index_root;

		tp_segment_writer_flush(&sink->writer);
		sink->writer.buffer_pos = SizeOfPageHeaderData;

		page_index_root = write_page_index(
				sink->index, sink->writer.pages, sink->writer.pages_allocated);
		header.page_index = page_index_root;
		header.num_pages  = sink->writer.pages_allocated;
	}

	/* Backpatch dict entries */
	{
		TpDictEntry *dict_entries;

		dict_entries = palloc_extended(
				num_terms * sizeof(TpDictEntry), MCXT_ALLOC_HUGE);
		for (i = 0; i < num_terms; i++)
		{
			dict_entries[i].skip_index_offset =
					header.skip_index_offset +
					((uint64)term_blocks[i].skip_entry_start *
					 sizeof(TpSkipEntry));
			dict_entries[i].block_count = term_blocks[i].block_count;
			dict_entries[i].doc_freq	= term_blocks[i].doc_freq;
		}

		merge_sink_write_at(
				sink,
				header.entries_offset,
				dict_entries,
				num_terms * sizeof(TpDictEntry));
		pfree(dict_entries);
	}

	/* Backpatch header */
	merge_sink_write_at(sink, 0, &header, sizeof(TpSegmentHeader));

	/* Finish writer */
	tp_segment_writer_finish(&sink->writer);

	/* Cleanup */
	pfree(string_offsets);
	pfree(term_blocks);
	free_merge_doc_mapping(&doc_mapping);
	tp_docmap_destroy(docmap);
}

/* ----------------------------------------------------------------
 * Level-based merge (uses pages sink)
 * ----------------------------------------------------------------
 */

/*
 * Merge up to max_merge segments from the specified level into a
 * single segment at level+1.  Returns the new segment's header
 * block, or InvalidBlockNumber on failure.
 */
BlockNumber
tp_merge_level_segments(Relation index, uint32 level, uint32 max_merge)
{
	TpIndexMetaPage metap;
	Buffer			metabuf;
	Page			metapage;
	BlockNumber		first_segment;
	uint32			total_at_level;
	uint32			segment_count;
	TpMergeSource  *sources;
	int				num_sources;
	int				i;
	BlockNumber		current;
	BlockNumber		remainder_head; /* First unmerged segment */
	TpMergedTerm   *merged_terms	 = NULL;
	uint32			num_merged_terms = 0;
	uint32			merged_capacity	 = 0;
	uint64			total_tokens	 = 0;
	uint64			src_num_docs_sum = 0; /* Σ source header.num_docs */
	BlockNumber		new_segment;
	MemoryContext	merge_ctx;
	MemoryContext	old_ctx;

	/* Page reclamation tracking (allocated outside merge context) */
	BlockNumber **segment_pages		   = NULL; /* Array of page arrays */
	uint32		 *segment_page_counts  = NULL; /* Count for each segment */
	uint32		  num_segments_tracked = 0;
	uint32		  total_pages_to_free  = 0;

	if (level >= TP_MAX_LEVELS - 1)
	{
		elog(WARNING,
			 "Cannot merge level %u - would exceed TP_MAX_LEVELS",
			 level);
		return InvalidBlockNumber;
	}

	/*
	 * Opportunistically return any already-past-horizon displaced
	 * pages to the FSM so the tombstone chain doesn't grow unbounded
	 * between vacuums.  The merge caller already holds the per-index
	 * LWLock EXCLUSIVE end-to-end, so own_lock=false.  Use the most
	 * conservative (NULL) horizon: it can only over-retain.
	 */
	{
		uint32 drained = tp_tombstone_drain(
				index, NULL, tp_reclaim_horizon(NULL), /* own_lock */ false);

		if (drained > 0)
			IndexFreeSpaceMapVacuum(index);
	}

	/* Read metapage to get segment chain */
	metabuf = ReadBuffer(index, 0);
	LockBuffer(metabuf, BUFFER_LOCK_SHARE);
	metapage = BufferGetPage(metabuf);
	metap	 = (TpIndexMetaPage)PageGetContents(metapage);

	first_segment  = metap->level_heads[level];
	total_at_level = metap->level_counts[level];

	UnlockReleaseBuffer(metabuf);

	if (first_segment == InvalidBlockNumber || total_at_level == 0)
	{
		return InvalidBlockNumber;
	}

	/*
	 * Merge at most max_merge segments per batch.  For normal
	 * compaction this is segments_per_level; for post-build
	 * compaction it can be UINT32_MAX to merge everything.
	 */
	segment_count = Min(total_at_level, max_merge);

	elog(DEBUG1,
		 "Merging %u of %u segments at level %u",
		 segment_count,
		 total_at_level,
		 level);

	/*
	 * Allocate page tracking arrays in current context (not merge context)
	 * so they survive the merge context deletion.
	 */
	segment_pages = (BlockNumber **)palloc0(
			sizeof(BlockNumber *) * segment_count);
	segment_page_counts = palloc0(sizeof(uint32) * segment_count);

	/* Create memory context for merge operation */
	merge_ctx = AllocSetContextCreate(
			CurrentMemoryContext, "Segment Merge", ALLOCSET_DEFAULT_SIZES);
	old_ctx = MemoryContextSwitchTo(merge_ctx);

	/* Allocate array for merge sources */
	sources		= palloc0(sizeof(TpMergeSource) * segment_count);
	num_sources = 0;

	/*
	 * Walk the chain, consuming exactly segment_count segments.
	 * Track segments_walked separately from num_sources because
	 * merge_source_init can fail (e.g. empty segment), in which
	 * case we still consumed the segment from the chain.
	 */
	{
		uint32 segments_walked = 0;

		current = first_segment;
		while (current != InvalidBlockNumber &&
			   segments_walked < segment_count)
		{
			TpSegmentReader *reader;
			BlockNumber		 next;
			uint64			 seg_tokens;

			reader = tp_segment_open(index, current);
			if (reader)
			{
				next	   = reader->header->next_segment;
				seg_tokens = reader->header->total_tokens;
				tp_segment_close(reader);

				/*
				 * Collect pages for later freeing (parent context).
				 */
				{
					MemoryContext save_ctx = MemoryContextSwitchTo(old_ctx);
					uint32		  page_count;

					page_count = tp_segment_collect_pages(
							index,
							current,
							&segment_pages[num_segments_tracked]);
					segment_page_counts[num_segments_tracked] = page_count;
					total_pages_to_free += page_count;
					num_segments_tracked++;

					MemoryContextSwitchTo(save_ctx);
				}

				if (merge_source_init(&sources[num_sources], index, current))
				{
					total_tokens += seg_tokens;
					src_num_docs_sum +=
							sources[num_sources].reader->header->num_docs;
					num_sources++;
				}

				current = next;
			}
			else
			{
				break;
			}
			segments_walked++;
		}

		/* Update segment_count to reflect actual segments consumed */
		segment_count = segments_walked;
	}

	/* First unmerged segment (may be InvalidBlockNumber) */
	remainder_head = current;

	if (num_sources == 0)
	{
		MemoryContextSwitchTo(old_ctx);
		MemoryContextDelete(merge_ctx);

		/* Clean up page tracking arrays */
		for (i = 0; i < (int)num_segments_tracked; i++)
		{
			if (segment_pages[i])
				pfree(segment_pages[i]);
		}
		pfree((void *)segment_pages);
		pfree(segment_page_counts);

		return InvalidBlockNumber;
	}

	/* Perform N-way merge */
	while (true)
	{
		int			  min_idx;
		const char	 *min_term;
		TpMergedTerm *current_merged;

		/* Find source with smallest term */
		min_idx = merge_find_min_source(sources, num_sources);
		if (min_idx < 0)
			break; /* All sources exhausted */

		min_term = sources[min_idx].current_term;

		/* Grow merged terms array if needed (may exceed 1GB for large
		 * corpora) */
		if (num_merged_terms >= merged_capacity)
		{
			merged_capacity = merged_capacity == 0 ? 1024
												   : merged_capacity * 2;
			if (merged_terms == NULL)
				merged_terms = palloc_extended(
						merged_capacity * sizeof(TpMergedTerm),
						MCXT_ALLOC_HUGE);
			else
				merged_terms = repalloc_huge(
						merged_terms, merged_capacity * sizeof(TpMergedTerm));
		}

		/* Initialize new merged term */
		current_merged					 = &merged_terms[num_merged_terms];
		current_merged->term_len		 = strlen(min_term);
		current_merged->term			 = pstrdup(min_term);
		current_merged->segment_refs	 = NULL;
		current_merged->num_segment_refs = 0;
		current_merged->segment_refs_capacity = 0;
		current_merged->posting_offset		  = 0; /* Set during write */
		current_merged->posting_count		  = 0; /* Set during write */
		num_merged_terms++;

		/*
		 * Record which segments have this term (don't load postings yet).
		 * IMPORTANT: Use current_merged->term (the pstrdup'd copy) for
		 * comparison, NOT min_term. When we advance sources[min_idx],
		 * merge_source_advance() frees sources[min_idx].current_term, which
		 * min_term points to. Using min_term after that would be
		 * use-after-free undefined behavior.
		 */
		for (i = 0; i < num_sources; i++)
		{
			if (sources[i].exhausted)
				continue;

			if (strcmp(sources[i].current_term, current_merged->term) == 0)
			{
				/* Record segment ref for later streaming merge */
				merged_term_add_segment_ref(
						current_merged, i, &sources[i].current_entry);

				/* Advance this source to next term */
				merge_source_advance(&sources[i]);
			}
		}

		/* Check for interrupt */
		CHECK_FOR_INTERRUPTS();
	}

	/* Write merged segment using pages sink */
	if (num_merged_terms > 0)
	{
		TpMergeSink sink;

		merge_sink_init_pages(&sink, index);
		if (sink.writer.pages_allocated == 0)
			elog(ERROR, "merge: failed to allocate segment pages");
		new_segment = sink.writer.pages[0];

		write_merged_segment_to_sink(
				&sink,
				merged_terms,
				num_merged_terms,
				sources,
				num_sources,
				level + 1,
				total_tokens,
				false);

		/* Free writer pages array */
		if (sink.writer.pages)
			pfree(sink.writer.pages);

		/* Free merged terms data */
		for (i = 0; i < (int)num_merged_terms; i++)
		{
			if (merged_terms[i].term)
				pfree(merged_terms[i].term);
			if (merged_terms[i].segment_refs)
				pfree(merged_terms[i].segment_refs);
		}
		pfree(merged_terms);
	}
	else
	{
		new_segment = InvalidBlockNumber;
	}

	/* Close all sources (after write is done with them) */
	for (i = 0; i < num_sources; i++)
	{
		merge_source_close(&sources[i]);
	}
	pfree(sources);

	/*
	 * Now that all source segment readers are closed (no more pinned buffers),
	 * flush dirty buffers to ensure merged segment is durable before updating
	 * the metapage.
	 */
	FlushRelationBuffers(index);

	MemoryContextSwitchTo(old_ctx);
	MemoryContextDelete(merge_ctx);

	if (new_segment == InvalidBlockNumber)
	{
		/* Clean up page tracking arrays on failure */
		for (i = 0; i < (int)num_segments_tracked; i++)
		{
			if (segment_pages[i])
				pfree(segment_pages[i]);
		}
		pfree((void *)segment_pages);
		pfree(segment_page_counts);

		return InvalidBlockNumber;
	}

	/*
	 * Update metapage: clear source level, add to target level, and
	 * apply shrinkage if the merged segment dropped V5-bitset-dead
	 * docs.  See TpIndexMetaPageData.total_docs in metapage.h for
	 * the invariant total_docs = Σ segment.num_docs.
	 *
	 * Phase 4 unified the WAL-logged and UNLOGGED / TEMP paths
	 * onto GenericXLog.  The standby's redo replays the page
	 * bytes directly; serialization against in-flight scans is no
	 * longer the rmgr's responsibility (#349) -- the chain_source
	 * read path takes the per-index LWLock around the buffer
	 * walk, so concurrent backend scans on the standby see a
	 * consistent metapage snapshot.
	 */
	{
		uint32 merged_docs	 = 0;
		uint64 merged_tokens = 0;
		uint64 docs_shrinkage;
		uint64 tokens_shrinkage;

		/* Read merged segment header for its num_docs / total_tokens. */
		{
			Buffer			 b = ReadBuffer(index, new_segment);
			Page			 p;
			TpSegmentHeader *h;

			LockBuffer(b, BUFFER_LOCK_SHARE);
			p			  = BufferGetPage(b);
			h			  = (TpSegmentHeader *)PageGetContents(p);
			merged_docs	  = h->num_docs;
			merged_tokens = h->total_tokens;
			UnlockReleaseBuffer(b);
		}

		docs_shrinkage	 = (src_num_docs_sum > (uint64)merged_docs)
								 ? src_num_docs_sum - (uint64)merged_docs
								 : 0;
		tokens_shrinkage = (total_tokens > merged_tokens)
								 ? total_tokens - merged_tokens
								 : 0;

		{
			GenericXLogState *xlog_state;
			Page			  meta_copy;
			TpIndexMetaPage	  meta_ptr;
			Buffer			  seg_buf	  = InvalidBuffer;
			FullTransactionId merged_fxid = ReadNextFullTransactionId();
			BlockNumber		  batch_head;

			/*
			 * Park the displaced pages BEFORE taking the metapage
			 * lock.  The new tombstone pages are unreferenced until
			 * we set pending_free_head in the swap record below, so
			 * a crash here only leaks them (no corruption).  We hold
			 * the per-index LWLock EXCLUSIVE for the whole merge, so
			 * no concurrent merge can change pending_free_head
			 * between this read and the swap record.
			 */
			{
				BlockNumber *flat = palloc(
						sizeof(BlockNumber) * Max(total_pages_to_free, 1));
				uint32 n = 0;
				int	   s;

				for (s = 0; s < (int)num_segments_tracked; s++)
				{
					uint32 p;

					for (p = 0; p < segment_page_counts[s]; p++)
						flat[n++] = segment_pages[s][p];
				}

				batch_head = tp_tombstone_enqueue(
						index,
						flat,
						n,
						merged_fxid,
						tp_tombstone_read_head(index));
				pfree(flat);
			}

			metabuf = ReadBuffer(index, 0);
			LockBuffer(metabuf, BUFFER_LOCK_EXCLUSIVE);

			xlog_state = GenericXLogStart(index);
			meta_copy  = GenericXLogRegisterBuffer(xlog_state, metabuf, 0);
			tp_metapage_upgrade_to_current(index, meta_copy);
			meta_ptr = (TpIndexMetaPage)PageGetContents(meta_copy);

			meta_ptr->level_heads[level]  = remainder_head;
			meta_ptr->level_counts[level] = total_at_level - segment_count;

			if (meta_ptr->level_heads[level + 1] != InvalidBlockNumber)
			{
				Page			 seg_page;
				TpSegmentHeader *seg_header;

				seg_buf = ReadBuffer(index, new_segment);
				LockBuffer(seg_buf, BUFFER_LOCK_EXCLUSIVE);
				seg_page = GenericXLogRegisterBuffer(xlog_state, seg_buf, 0);
				((PageHeader)seg_page)->pd_lower = BLCKSZ;
				seg_header = (TpSegmentHeader *)PageGetContents(seg_page);
				seg_header->next_segment = meta_ptr->level_heads[level + 1];
			}

			meta_ptr->level_heads[level + 1] = new_segment;
			meta_ptr->level_counts[level + 1]++;

			meta_ptr->total_docs = (meta_ptr->total_docs >= docs_shrinkage)
										 ? meta_ptr->total_docs -
												   docs_shrinkage
										 : 0;
			meta_ptr->total_len	 = (meta_ptr->total_len >= tokens_shrinkage)
										 ? meta_ptr->total_len -
												   tokens_shrinkage
										 : 0;

			/*
			 * Prepend the freshly written batch (head = batch_head,
			 * tail already chained to the old pending_free_head) to
			 * the deferred-free chain.  This transitions the
			 * displaced pages from "referenced by the level chain"
			 * to "referenced by the tombstone list" atomically with
			 * the level-swap, with no writes to the displaced data
			 * pages.
			 */
			if (batch_head != InvalidBlockNumber)
				meta_ptr->pending_free_head = batch_head;

			GenericXLogFinish(xlog_state);
			if (BufferIsValid(seg_buf))
				UnlockReleaseBuffer(seg_buf);
			UnlockReleaseBuffer(metabuf);
		}
	}

	/*
	 * The merged source segments' pages were parked in the tombstone
	 * chain (set as pending_free_head in the swap record above), not
	 * freed.  They are returned to the FSM by a later drain once their
	 * merge horizon is past every standby snapshot.
	 */

	elog(DEBUG1,
		 "Merged %u segments from L%u into L%u segment at block %u "
		 "(%u terms, parked %u pages)",
		 segment_count,
		 level,
		 level + 1,
		 new_segment,
		 num_merged_terms,
		 total_pages_to_free);

	/* Clean up page tracking arrays */
	for (i = 0; i < (int)num_segments_tracked; i++)
	{
		if (segment_pages[i])
			pfree(segment_pages[i]);
	}
	pfree((void *)segment_pages);
	pfree(segment_page_counts);

	return new_segment;
}

/*
 * Check if a level needs compaction and trigger merge if so.
 */
void
tp_maybe_compact_level(Relation index, uint32 level)
{
	TpIndexMetaPage metap;
	Buffer			metabuf;
	Page			metapage;
	uint16			level_count;

	if (level >= TP_MAX_LEVELS - 1)
		return;

	/* Check if level needs compaction */
	metabuf = ReadBuffer(index, 0);
	LockBuffer(metabuf, BUFFER_LOCK_SHARE);
	metapage = BufferGetPage(metabuf);
	metap	 = (TpIndexMetaPage)PageGetContents(metapage);

	level_count = metap->level_counts[level];

	UnlockReleaseBuffer(metabuf);

	if (level_count < (uint16)tp_segments_per_level)
		return; /* Level not full */

	/*
	 * Merge batches of segments_per_level until the level is
	 * below threshold.  Each batch produces one segment at
	 * level+1; after the loop we check if that level also needs
	 * compaction.
	 */
	while (level_count >= (uint16)tp_segments_per_level)
	{
		if (tp_merge_level_segments(
					index, level, (uint32)tp_segments_per_level) ==
			InvalidBlockNumber)
			break;

		/* Re-read the level count after merge */
		metabuf = ReadBuffer(index, 0);
		LockBuffer(metabuf, BUFFER_LOCK_SHARE);
		metapage	= BufferGetPage(metabuf);
		metap		= (TpIndexMetaPage)PageGetContents(metapage);
		level_count = metap->level_counts[level];
		UnlockReleaseBuffer(metabuf);
	}

	/* Check if next level now needs compaction */
	tp_maybe_compact_level(index, level + 1);
}

/*
 * Force-merge all segments into a single segment, à la Lucene's
 * forceMerge(1).  Merges ALL segments at each level in a single
 * batch, ignoring the segments_per_level threshold.
 */
void
tp_force_merge_all(Relation index)
{
	for (uint32 level = 0; level < TP_MAX_LEVELS - 1; level++)
	{
		Buffer			metabuf;
		Page			metapage;
		TpIndexMetaPage metap;
		uint16			count;

		metabuf = ReadBuffer(index, 0);
		LockBuffer(metabuf, BUFFER_LOCK_SHARE);
		metapage = BufferGetPage(metabuf);
		metap	 = (TpIndexMetaPage)PageGetContents(metapage);
		count	 = metap->level_counts[level];
		UnlockReleaseBuffer(metabuf);

		if (count < 2)
			break; /* Nothing to merge at this level or above */

		tp_merge_level_segments(index, level, UINT32_MAX);
	}
}
