-- BMW Multi-term WAND Traversal Test
--
-- Regression test for doc-ID ordered traversal in multi-term queries.
-- Ensures documents at different block positions across posting lists
-- are correctly scored. Uses validation.sql to verify scores match
-- the reference BM25 implementation.

CREATE EXTENSION pg_textsearch;

\set ECHO none
\i test/sql/validation.sql
\set ECHO all

-- ============================================================
-- TEST: Multi-term documents score correctly across block boundaries
-- ============================================================

CREATE TABLE bmw_bug (id SERIAL PRIMARY KEY, content TEXT);
CREATE INDEX bmw_bug_idx ON bmw_bug USING bm25(content) WITH (text_config='english');

-- Insert in order that puts multi-term doc at different block positions:
-- 5 alpha-only docs, then 1 multi-term, then 200 beta-only docs
INSERT INTO bmw_bug (content) SELECT 'alpha only ' || i FROM generate_series(1, 5) i;
INSERT INTO bmw_bug (content) VALUES ('alpha beta both terms here');  -- id=6
INSERT INTO bmw_bug (content) SELECT 'beta only ' || i FROM generate_series(7, 206) i;

-- Spill to segment (creates single segment with all 206 docs)
SELECT bm25_spill_index('bmw_bug_idx');

-- Posting list layout in segment:
-- "alpha": 6 postings (docs 1-5, 6) - fits in single block
-- "beta": 201 postings (doc 6, docs 7-206)
--   - Block 0: docs 6-133
--   - Block 1: docs 134-206
--
-- Doc 6 is the only multi-term document.

-- Validate BMW produces correct scores for multi-term query
SELECT validate_bm25_scoring('bmw_bug', 'content', 'bmw_bug_idx',
    'alpha beta', 'english', 1.2, 0.75) as two_term_valid;

DROP TABLE bmw_bug;

-- ============================================================
-- TEST: 3-term query with multiple blocks (buffer management)
-- ============================================================
-- This tests a bug where zero-copy buffer pins were shared with the
-- reader's cached buffer. When initializing multiple term iterators,
-- reading the dictionary for term N could release the buffer that
-- term N-1's iterator was still using.

CREATE TABLE three_term (id SERIAL PRIMARY KEY, content TEXT);
CREATE INDEX three_term_idx ON three_term USING bm25(content)
    WITH (text_config='english');

-- Create layout to test multi-term scoring
INSERT INTO three_term (content)
    SELECT 'alpha only ' || i FROM generate_series(1, 3) i;
INSERT INTO three_term (content)
    VALUES ('alpha beta two terms');  -- id=4
INSERT INTO three_term (content)
    SELECT 'beta only ' || i FROM generate_series(5, 7) i;
INSERT INTO three_term (content)
    VALUES ('alpha beta gamma three terms here');  -- id=8
INSERT INTO three_term (content)
    SELECT 'gamma only ' || i FROM generate_series(9, 11) i;

SELECT bm25_spill_index('three_term_idx');

-- Validate BMW produces correct scores for 3-term query
SELECT validate_bm25_scoring('three_term', 'content', 'three_term_idx',
    'alpha beta gamma', 'english', 1.2, 0.75) as three_term_valid;

DROP TABLE three_term;

-- ============================================================
-- TEST: 8+ term queries with WAND pivot selection
-- ============================================================
-- Validates that WAND pivot selection produces correct results
-- for many-term queries across multiple blocks.

CREATE TABLE wand_many_terms (id SERIAL PRIMARY KEY, content TEXT);
CREATE INDEX wand_many_terms_idx ON wand_many_terms USING bm25(content)
    WITH (text_config='english');

-- Create 500 docs with varying term coverage
INSERT INTO wand_many_terms (content)
SELECT
    CASE
        WHEN i % 100 = 0 THEN
            'alpha beta gamma delta epsilon zeta eta theta'
        WHEN i % 50 = 0 THEN
            'alpha beta gamma delta epsilon zeta'
        WHEN i % 10 = 0 THEN
            'alpha beta gamma delta'
        WHEN i % 5 = 0 THEN
            'alpha beta gamma'
        WHEN i % 2 = 0 THEN
            'alpha beta'
        ELSE
            'alpha'
    END || ' document ' || i
FROM generate_series(1, 500) i;

SELECT bm25_spill_index('wand_many_terms_idx');

-- 8-term query: WAND vs exhaustive (LIMIT 10 avoids tie boundary)
WITH bmw AS (
    SELECT id, content <@> 'alpha beta gamma delta epsilon zeta eta theta'::bm25query as score
    FROM wand_many_terms
    ORDER BY content <@> 'alpha beta gamma delta epsilon zeta eta theta'::bm25query LIMIT 10
),
exhaustive AS (
    SELECT id, score FROM (
        SELECT id, content <@> 'alpha beta gamma delta epsilon zeta eta theta'::bm25query as score
        FROM wand_many_terms
        ORDER BY content <@> 'alpha beta gamma delta epsilon zeta eta theta'::bm25query
    ) x LIMIT 10
)
SELECT 'wand-8-term' as test,
    CASE WHEN COUNT(*) = 0 THEN 'PASS' ELSE 'FAIL' END as result
FROM (SELECT * FROM bmw EXCEPT SELECT * FROM exhaustive) diff;

-- Validate scores match reference BM25 computation
SELECT validate_bm25_scoring('wand_many_terms', 'content',
    'wand_many_terms_idx',
    'alpha beta gamma delta epsilon zeta eta theta',
    'english', 1.2, 0.75) as eight_term_valid;

DROP TABLE wand_many_terms;

DROP EXTENSION pg_textsearch CASCADE;
