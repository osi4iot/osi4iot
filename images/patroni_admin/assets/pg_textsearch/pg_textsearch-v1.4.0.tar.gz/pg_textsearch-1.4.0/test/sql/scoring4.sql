-- Test case: scoring4
-- Generated BM25 test with 2 documents and 1 queries
-- Testing both bulk build and incremental build modes
CREATE EXTENSION IF NOT EXISTS pg_textsearch;

\set ECHO none
\i test/sql/validation.sql
\set ECHO all

SET pg_textsearch.log_scores = true;
SET enable_seqscan = off;

-- MODE 1: Bulk build (insert data, then create index)
CREATE TABLE scoring4_bulk (
    id SERIAL PRIMARY KEY,
    content TEXT
);

-- Insert test documents
INSERT INTO scoring4_bulk (content) VALUES ('goodbye world');
INSERT INTO scoring4_bulk (content) VALUES ('goodbyes are hard');

-- Create index after data insertion (bulk build)
CREATE INDEX scoring4_bulk_idx ON scoring4_bulk USING bm25(content)
  WITH (text_config='english', k1=1.2, b=0.75);

-- Bulk mode query 1: 'goodbye'
SELECT id, content, ROUND((content <@> 'goodbye')::numeric, 4) as score
FROM scoring4_bulk
ORDER BY content <@> 'goodbye', id;

-- Validate BM25 scoring for 'goodbye'
SELECT validate_bm25_scoring('scoring4_bulk', 'content', 'scoring4_bulk_idx', 'goodbye', 'english', 1.2, 0.75) as goodbye_bulk_valid;

-- MODE 2: Incremental build (create index, then insert data)
CREATE TABLE scoring4_incr (
    id SERIAL PRIMARY KEY,
    content TEXT
);

-- Create index before data insertion (incremental build)
CREATE INDEX scoring4_incr_idx ON scoring4_incr USING bm25(content)
  WITH (text_config='english', k1=1.2, b=0.75);

-- Insert test documents incrementally
INSERT INTO scoring4_incr (content) VALUES ('goodbye world');
INSERT INTO scoring4_incr (content) VALUES ('goodbyes are hard');

-- Incremental mode query 1: 'goodbye'
SELECT id, content, ROUND((content <@> 'goodbye')::numeric, 4) as score
FROM scoring4_incr
ORDER BY content <@> 'goodbye', id;

-- Validate BM25 scoring for 'goodbye' (incremental)
SELECT validate_bm25_scoring('scoring4_incr', 'content', 'scoring4_incr_idx', 'goodbye', 'english', 1.2, 0.75) as goodbye_incr_valid;

-- Cleanup
DROP TABLE scoring4_bulk CASCADE;
DROP TABLE scoring4_incr CASCADE;
DROP EXTENSION pg_textsearch CASCADE;
