-- Test case: scoring6
-- Generated BM25 test with 2 documents and 3 queries
-- Testing both bulk build and incremental build modes
CREATE EXTENSION IF NOT EXISTS pg_textsearch;

\set ECHO none
\i test/sql/validation.sql
\set ECHO all

SET pg_textsearch.log_scores = true;
SET enable_seqscan = off;

-- MODE 1: Bulk build (insert data, then create index)
CREATE TABLE scoring6_bulk (
    id SERIAL PRIMARY KEY,
    content TEXT
);

-- Insert test documents
INSERT INTO scoring6_bulk (content) VALUES ('hello, world!');
INSERT INTO scoring6_bulk (content) VALUES ('goodbye cruel world...');

-- Create index after data insertion (bulk build)
CREATE INDEX scoring6_bulk_idx ON scoring6_bulk USING bm25(content)
  WITH (text_config='english', k1=1.2, b=0.75);

-- Bulk mode query 1: 'hello'
SELECT id, content, ROUND((content <@> 'hello')::numeric, 4) as score
FROM scoring6_bulk
ORDER BY content <@> 'hello', id;

-- Validate BM25 scoring for 'hello'
SELECT validate_bm25_scoring('scoring6_bulk', 'content', 'scoring6_bulk_idx', 'hello', 'english', 1.2, 0.75) as hello_bulk_valid;

-- Bulk mode query 2: 'goodbye'
SELECT id, content, ROUND((content <@> 'goodbye')::numeric, 4) as score
FROM scoring6_bulk
ORDER BY content <@> 'goodbye', id;

-- Validate BM25 scoring for 'goodbye'
SELECT validate_bm25_scoring('scoring6_bulk', 'content', 'scoring6_bulk_idx', 'goodbye', 'english', 1.2, 0.75) as goodbye_bulk_valid;

-- Bulk mode query 3: 'world'
SELECT id, content, ROUND((content <@> 'world')::numeric, 4) as score
FROM scoring6_bulk
ORDER BY content <@> 'world', id;

-- Validate BM25 scoring for 'world'
SELECT validate_bm25_scoring('scoring6_bulk', 'content', 'scoring6_bulk_idx', 'world', 'english', 1.2, 0.75) as world_bulk_valid;

-- MODE 2: Incremental build (create index, then insert data)
CREATE TABLE scoring6_incr (
    id SERIAL PRIMARY KEY,
    content TEXT
);

-- Create index before data insertion (incremental build)
CREATE INDEX scoring6_incr_idx ON scoring6_incr USING bm25(content)
  WITH (text_config='english', k1=1.2, b=0.75);

-- Insert test documents incrementally
INSERT INTO scoring6_incr (content) VALUES ('hello, world!');
INSERT INTO scoring6_incr (content) VALUES ('goodbye cruel world...');

-- Incremental mode query 1: 'hello'
SELECT id, content, ROUND((content <@> 'hello')::numeric, 4) as score
FROM scoring6_incr
ORDER BY content <@> 'hello', id;

-- Validate BM25 scoring for 'hello' (incremental)
SELECT validate_bm25_scoring('scoring6_incr', 'content', 'scoring6_incr_idx', 'hello', 'english', 1.2, 0.75) as hello_incr_valid;

-- Incremental mode query 2: 'goodbye'
SELECT id, content, ROUND((content <@> 'goodbye')::numeric, 4) as score
FROM scoring6_incr
ORDER BY content <@> 'goodbye', id;

-- Validate BM25 scoring for 'goodbye' (incremental)
SELECT validate_bm25_scoring('scoring6_incr', 'content', 'scoring6_incr_idx', 'goodbye', 'english', 1.2, 0.75) as goodbye_incr_valid;

-- Incremental mode query 3: 'world'
SELECT id, content, ROUND((content <@> 'world')::numeric, 4) as score
FROM scoring6_incr
ORDER BY content <@> 'world', id;

-- Validate BM25 scoring for 'world' (incremental)
SELECT validate_bm25_scoring('scoring6_incr', 'content', 'scoring6_incr_idx', 'world', 'english', 1.2, 0.75) as world_incr_valid;

-- Cleanup
DROP TABLE scoring6_bulk CASCADE;
DROP TABLE scoring6_incr CASCADE;
DROP EXTENSION pg_textsearch CASCADE;
