-- BMW (Block-Max WAND) Algorithm Tests
-- Tests the top-k optimization for both single-term and multi-term queries

-- Setup: Create extension
CREATE EXTENSION pg_textsearch;

-- Force index scan so ORDER BY uses the BM25 index (small tables
-- would otherwise prefer seq scan, returning non-matching rows)
SET enable_seqscan = off;

\set ECHO none
\i test/sql/validation.sql
\set ECHO all

-- ============================================================
-- SECTION 1: Basic BMW correctness
-- ============================================================

CREATE TABLE bmw_basic (id SERIAL PRIMARY KEY, content TEXT);

-- Insert documents with known term frequencies
INSERT INTO bmw_basic (content) VALUES
    ('apple apple apple'),           -- id=1, tf=3
    ('apple apple'),                 -- id=2, tf=2
    ('apple'),                       -- id=3, tf=1
    ('apple apple apple apple'),     -- id=4, tf=4
    ('banana'),                      -- id=5, no apple
    ('apple banana'),                -- id=6, tf=1
    ('apple apple banana banana');   -- id=7, tf=2

CREATE INDEX bmw_basic_idx ON bmw_basic USING bm25(content)
    WITH (text_config='english');

-- Test: Single-term BMW should return docs in score order
SELECT id, content <@> 'apple'::bm25query as score
FROM bmw_basic
ORDER BY score LIMIT 5;

DROP TABLE bmw_basic;

-- ============================================================
-- SECTION 2: Empty and edge result counts
-- ============================================================

CREATE TABLE bmw_empty (id SERIAL PRIMARY KEY, content TEXT);
INSERT INTO bmw_empty (content) VALUES
    ('cat dog bird'),
    ('fish whale shark'),
    ('lion tiger bear');

CREATE INDEX bmw_empty_idx ON bmw_empty USING bm25(content)
    WITH (text_config='english');

-- Test: Query term not in corpus (empty results)
SELECT id FROM bmw_empty
ORDER BY content <@> 'elephant'::bm25query LIMIT 10;

-- Test: Only 1 document matches
SELECT id FROM bmw_empty
ORDER BY content <@> 'whale'::bm25query LIMIT 10;

-- Test: Fewer results than LIMIT (3 docs match, LIMIT 10)
SELECT id FROM bmw_empty
ORDER BY content <@> 'cat fish lion'::bm25query LIMIT 10;

DROP TABLE bmw_empty;

-- ============================================================
-- SECTION 3: Tie-breaking with identical scores
-- ============================================================

CREATE TABLE bmw_ties (id SERIAL PRIMARY KEY, content TEXT);

-- Create documents with IDENTICAL scores (same tf, same doc length)
INSERT INTO bmw_ties (content) VALUES
    ('unique term here'),      -- id=1
    ('exact same length'),     -- id=2, same length as id=1
    ('exact same length'),     -- id=3, same length
    ('exact same length'),     -- id=4, same length
    ('exact same length');     -- id=5, same length

CREATE INDEX bmw_ties_idx ON bmw_ties USING bm25(content)
    WITH (text_config='english');

-- Test: Documents with identical scores should be ordered by CTID (id)
-- All "exact same length" docs have tf=1 and same doc_len
SELECT id, content <@> 'exact'::bm25query as score
FROM bmw_ties
ORDER BY content <@> 'exact'::bm25query LIMIT 10;

DROP TABLE bmw_ties;

-- ============================================================
-- SECTION 4: LIMIT edge cases
-- ============================================================

CREATE TABLE bmw_limits (id SERIAL PRIMARY KEY, content TEXT);

-- Create 20 documents with term "test"
INSERT INTO bmw_limits (content)
SELECT 'test document number ' || i
FROM generate_series(1, 20) i;

CREATE INDEX bmw_limits_idx ON bmw_limits USING bm25(content)
    WITH (text_config='english');

-- Test: LIMIT 1 (minimum)
SELECT id FROM bmw_limits
ORDER BY content <@> 'test'::bm25query LIMIT 1;

-- Test: LIMIT equals exact document count
SELECT COUNT(*) FROM (
    SELECT id FROM bmw_limits
    ORDER BY content <@> 'test'::bm25query LIMIT 20
) x;

-- Test: LIMIT exceeds document count
SELECT COUNT(*) FROM (
    SELECT id FROM bmw_limits
    ORDER BY content <@> 'test'::bm25query LIMIT 100
) x;

DROP TABLE bmw_limits;

-- ============================================================
-- SECTION 5: Multi-term query edge cases
-- ============================================================

CREATE TABLE bmw_multi (id SERIAL PRIMARY KEY, content TEXT);

INSERT INTO bmw_multi (content) VALUES
    ('alpha beta gamma'),           -- id=1, has all 3
    ('alpha beta'),                 -- id=2, has 2
    ('alpha'),                      -- id=3, has 1
    ('beta gamma'),                 -- id=4, has 2
    ('delta epsilon'),              -- id=5, has none
    ('alpha alpha alpha beta'),     -- id=6, high tf for alpha
    ('gamma gamma gamma gamma');    -- id=7, high tf for gamma

CREATE INDEX bmw_multi_idx ON bmw_multi USING bm25(content)
    WITH (text_config='english');

-- Test: 2-term query
SELECT id, content <@> 'alpha beta'::bm25query as score
FROM bmw_multi
ORDER BY score LIMIT 5;

-- Test: 3-term query
SELECT id, content <@> 'alpha beta gamma'::bm25query as score
FROM bmw_multi
ORDER BY score LIMIT 5;

-- Test: Query with non-existent term (partial match)
SELECT id, content <@> 'alpha nonexistent'::bm25query as score
FROM bmw_multi
ORDER BY score LIMIT 5;

-- Test: Query where all terms are non-existent
SELECT id FROM bmw_multi
ORDER BY content <@> 'xxx yyy zzz'::bm25query LIMIT 5;

DROP TABLE bmw_multi;

-- ============================================================
-- SECTION 6: 8-term boundary (max for multi-term BMW)
-- ============================================================

CREATE TABLE bmw_8term (id SERIAL PRIMARY KEY, content TEXT);

INSERT INTO bmw_8term (content) VALUES
    ('one two three four five six seven eight nine ten'),
    ('one two three four'),
    ('five six seven eight'),
    ('one three five seven nine'),
    ('two four six eight ten');

CREATE INDEX bmw_8term_idx ON bmw_8term USING bm25(content)
    WITH (text_config='english');

-- Test: Exactly 8 terms (should use multi-term BMW)
SELECT id, content <@> 'one two three four five six seven eight'::bm25query as score
FROM bmw_8term
ORDER BY score LIMIT 5;

-- Test: 9+ terms (should fall back to exhaustive, but still work)
SELECT id, content <@> 'one two three four five six seven eight nine'::bm25query as score
FROM bmw_8term
ORDER BY score LIMIT 5;

DROP TABLE bmw_8term;

-- ============================================================
-- SECTION 7: Document length extremes
-- ============================================================

CREATE TABLE bmw_lengths (id SERIAL PRIMARY KEY, content TEXT);

INSERT INTO bmw_lengths (content) VALUES
    ('x'),                                              -- id=1, very short
    ('word'),                                           -- id=2, short
    (repeat('word ', 100)),                             -- id=3, medium (100 words)
    (repeat('word ', 1000)),                            -- id=4, long (1000 words)
    ('word ' || repeat('filler ', 500));                -- id=5, word + filler

CREATE INDEX bmw_lengths_idx ON bmw_lengths USING bm25(content)
    WITH (text_config='english');

-- Test: Query should rank by BM25 (considers doc length)
-- Short docs with term should score higher than long docs
SELECT id, length(content) as doc_chars,
       content <@> 'word'::bm25query as score
FROM bmw_lengths
ORDER BY content <@> 'word'::bm25query LIMIT 5;

DROP TABLE bmw_lengths;

-- ============================================================
-- SECTION 8: High term frequency
-- ============================================================

CREATE TABLE bmw_highfreq (id SERIAL PRIMARY KEY, content TEXT);

INSERT INTO bmw_highfreq (content) VALUES
    (repeat('keyword ', 1)),      -- id=1, tf=1
    (repeat('keyword ', 10)),     -- id=2, tf=10
    (repeat('keyword ', 50)),     -- id=3, tf=50
    (repeat('keyword ', 100)),    -- id=4, tf=100
    (repeat('keyword ', 200));    -- id=5, tf=200

CREATE INDEX bmw_highfreq_idx ON bmw_highfreq USING bm25(content)
    WITH (text_config='english');

-- Test: High TF documents should rank higher (with saturation)
SELECT id, content <@> 'keyword'::bm25query as score
FROM bmw_highfreq
ORDER BY content <@> 'keyword'::bm25query LIMIT 5;

-- Verify: Order should be 5,4,3,2,1 (highest tf first)
-- But scores should show diminishing returns due to BM25 saturation

DROP TABLE bmw_highfreq;

-- ============================================================
-- SECTION 9: Segment + Memtable combination
-- ============================================================

CREATE TABLE bmw_hybrid (id SERIAL PRIMARY KEY, content TEXT);

-- Insert batch 1 (will go to segment via CREATE INDEX)
INSERT INTO bmw_hybrid (content)
SELECT 'segment document ' || i || ' with searchterm'
FROM generate_series(1, 500) i;

CREATE INDEX bmw_hybrid_idx ON bmw_hybrid USING bm25(content)
    WITH (text_config='english');

-- Batch 2: insert and spill to create a second segment
INSERT INTO bmw_hybrid (content)
SELECT 'more segment data ' || i || ' searchterm'
FROM generate_series(501, 1000) i;

SELECT bm25_spill_index('bmw_hybrid_idx');

-- Insert recent data (stays in memtable)
INSERT INTO bmw_hybrid (content) VALUES
    ('fresh memtable searchterm searchterm searchterm'),  -- High relevance
    ('another memtable searchterm searchterm');

-- Test: BMW should find results from both segment and memtable
-- The memtable docs with higher tf should rank at top
SELECT id, content <@> 'searchterm'::bm25query as score
FROM bmw_hybrid
ORDER BY content <@> 'searchterm'::bm25query LIMIT 10;
DROP TABLE bmw_hybrid;

-- ============================================================
-- SECTION 10: Validate BMW equals exhaustive (LARGE SCALE)
-- ============================================================
-- CRITICAL: Must use >128 docs to test block skipping!
-- Block size is 128 docs, so we need multiple blocks for skip testing.

CREATE TABLE bmw_validate (id SERIAL PRIMARY KEY, content TEXT);

-- Create 1000 diverse documents - spans ~8 blocks
-- Varying term frequencies to create score diversity
INSERT INTO bmw_validate (content)
SELECT
    CASE (i % 10)
        WHEN 0 THEN 'apple apple apple banana cherry'  -- high apple tf
        WHEN 1 THEN 'apple apple banana'
        WHEN 2 THEN 'cherry cherry cherry'
        WHEN 3 THEN 'apple cherry'
        WHEN 4 THEN 'banana banana cherry cherry'
        WHEN 5 THEN 'apple'
        WHEN 6 THEN 'banana apple cherry'
        WHEN 7 THEN 'cherry banana'
        WHEN 8 THEN 'apple apple apple apple'  -- highest apple tf
        WHEN 9 THEN 'banana'
    END || ' document number ' || i
FROM generate_series(1, 1000) i;

-- Force to segment with low memory limit
CREATE INDEX bmw_validate_idx ON bmw_validate USING bm25(content)
    WITH (text_config='english');

-- Test: BMW (LIMIT) should match exhaustive (subquery LIMIT)
-- Single-term
WITH bmw AS (
    SELECT id, content <@> 'apple'::bm25query as score
    FROM bmw_validate
    ORDER BY content <@> 'apple'::bm25query LIMIT 20
),
exhaustive AS (
    SELECT id, score FROM (
        SELECT id, content <@> 'apple'::bm25query as score
        FROM bmw_validate
        ORDER BY content <@> 'apple'::bm25query
    ) x LIMIT 20
)
SELECT 'single-term' as test,
    CASE WHEN COUNT(*) = 0 THEN 'PASS' ELSE 'FAIL' END as result
FROM (SELECT * FROM bmw EXCEPT SELECT * FROM exhaustive) diff;

-- Multi-term
WITH bmw AS (
    SELECT id, content <@> 'apple banana'::bm25query as score
    FROM bmw_validate
    ORDER BY content <@> 'apple banana'::bm25query LIMIT 20
),
exhaustive AS (
    SELECT id, score FROM (
        SELECT id, content <@> 'apple banana'::bm25query as score
        FROM bmw_validate
        ORDER BY content <@> 'apple banana'::bm25query
    ) x LIMIT 20
)
SELECT 'multi-term' as test,
    CASE WHEN COUNT(*) = 0 THEN 'PASS' ELSE 'FAIL' END as result
FROM (SELECT * FROM bmw EXCEPT SELECT * FROM exhaustive) diff;

-- Three-term
WITH bmw AS (
    SELECT id, content <@> 'apple banana cherry'::bm25query as score
    FROM bmw_validate
    ORDER BY content <@> 'apple banana cherry'::bm25query LIMIT 20
),
exhaustive AS (
    SELECT id, score FROM (
        SELECT id, content <@> 'apple banana cherry'::bm25query as score
        FROM bmw_validate
        ORDER BY content <@> 'apple banana cherry'::bm25query
    ) x LIMIT 20
)
SELECT 'three-term' as test,
    CASE WHEN COUNT(*) = 0 THEN 'PASS' ELSE 'FAIL' END as result
FROM (SELECT * FROM bmw EXCEPT SELECT * FROM exhaustive) diff;

DROP TABLE bmw_validate;

-- ============================================================
-- SECTION 11: Score monotonicity with multiple blocks
-- ============================================================
-- Use 500 docs to span multiple blocks (~4 blocks)

CREATE TABLE bmw_monotonic (id SERIAL PRIMARY KEY, content TEXT);

-- Create varying scores by varying term frequency
INSERT INTO bmw_monotonic (content)
SELECT
    CASE
        WHEN i % 50 = 0 THEN repeat('target ', 5)  -- high tf every 50 docs
        WHEN i % 10 = 0 THEN repeat('target ', 3)  -- medium tf every 10 docs
        ELSE 'target other words here'              -- low tf
    END || ' doc' || i
FROM generate_series(1, 500) i;

CREATE INDEX bmw_monotonic_idx ON bmw_monotonic USING bm25(content)
    WITH (text_config='english');

-- Test: Scores must be monotonically descending (more negative)
-- This tests that BMW correctly orders results from multiple blocks
WITH ranked AS (
    SELECT id,
           content <@> 'target'::bm25query as score,
           LAG(content <@> 'target'::bm25query) OVER (ORDER BY content <@> 'target'::bm25query) as prev_score
    FROM bmw_monotonic
    ORDER BY content <@> 'target'::bm25query
    LIMIT 50
)
SELECT 'monotonic-multiblock' as test,
    CASE WHEN COUNT(*) = 0 THEN 'PASS' ELSE 'FAIL' END as result
FROM ranked
WHERE prev_score IS NOT NULL AND score < prev_score;

DROP TABLE bmw_monotonic;

-- ============================================================
-- SECTION 12: Block boundary stress test
-- ============================================================
-- Test with 640 docs = exactly 5 blocks of 128 docs each
-- Place high-scoring docs at specific positions to test block skipping

CREATE TABLE bmw_blocks (id SERIAL PRIMARY KEY, content TEXT);

-- Insert 640 base documents (5 blocks worth)
INSERT INTO bmw_blocks (content)
SELECT 'baseline searchword document ' || i
FROM generate_series(1, 640) i;

-- Insert high-scoring docs at specific block positions:
-- These should all appear in top-10 regardless of which block they're in
INSERT INTO bmw_blocks (content) VALUES
    ('searchword searchword searchword searchword searchword'),  -- id=641, tf=5
    ('searchword searchword searchword searchword'),             -- id=642, tf=4
    ('searchword searchword searchword');                        -- id=643, tf=3

CREATE INDEX bmw_blocks_idx ON bmw_blocks USING bm25(content)
    WITH (text_config='english');

-- Test: High-tf docs (641,642,643) must be in top results
-- This validates block-max scoring finds them across multiple blocks
SELECT id, content <@> 'searchword'::bm25query as score
FROM bmw_blocks
ORDER BY content <@> 'searchword'::bm25query LIMIT 10;

-- Validation: top 3 must be our high-tf docs
WITH top3 AS (
    SELECT id FROM bmw_blocks
    ORDER BY content <@> 'searchword'::bm25query LIMIT 3
)
SELECT 'block-boundary' as test,
    CASE WHEN COUNT(*) = 3 AND
              641 IN (SELECT id FROM top3) AND
              642 IN (SELECT id FROM top3) AND
              643 IN (SELECT id FROM top3)
         THEN 'PASS' ELSE 'FAIL' END as result
FROM top3;

DROP TABLE bmw_blocks;

-- ============================================================
-- SECTION 13: Repeated query terms
-- ============================================================

CREATE TABLE bmw_repeat (id SERIAL PRIMARY KEY, content TEXT);

INSERT INTO bmw_repeat (content) VALUES
    ('cat cat cat'),
    ('cat dog'),
    ('dog dog dog');

CREATE INDEX bmw_repeat_idx ON bmw_repeat USING bm25(content)
    WITH (text_config='english');

-- Test: Repeated terms in query should boost relevance
SELECT id, content <@> 'cat cat'::bm25query as score
FROM bmw_repeat
ORDER BY score LIMIT 5;

DROP TABLE bmw_repeat;

-- ============================================================
-- SECTION 14: Unicode and special characters
-- ============================================================

CREATE TABLE bmw_unicode (id SERIAL PRIMARY KEY, content TEXT);

INSERT INTO bmw_unicode (content) VALUES
    ('cafe with accent'),
    ('naïve approach'),
    ('北京 beijing china'),
    ('emoji test'),
    ('simple ascii text');

CREATE INDEX bmw_unicode_idx ON bmw_unicode USING bm25(content)
    WITH (text_config='simple');  -- simple config for unicode

-- Test: Should handle various character sets
SELECT id, content <@> 'beijing'::bm25query as score
FROM bmw_unicode
ORDER BY score LIMIT 5;

SELECT id, content <@> 'simple'::bm25query as score
FROM bmw_unicode
ORDER BY score LIMIT 5;

DROP TABLE bmw_unicode;

-- ============================================================
-- SECTION 15: Top-K scattered across blocks
-- ============================================================
-- This is the CRITICAL test for BMW: best docs are spread across
-- different blocks, forcing the algorithm to check multiple blocks.

CREATE TABLE bmw_scattered (id SERIAL PRIMARY KEY, content TEXT);

-- Create 1000 docs where high-scoring docs are deliberately scattered:
-- - Every 100th doc (100,200,300...) has tf=4 (highest)
-- - Every 50th doc has tf=3
-- - Every 10th doc has tf=2
-- - Others have tf=1
-- This ensures top-10 must come from DIFFERENT blocks
INSERT INTO bmw_scattered (content)
SELECT
    CASE
        WHEN i % 100 = 0 THEN 'scattered scattered scattered scattered'
        WHEN i % 50 = 0 THEN 'scattered scattered scattered'
        WHEN i % 10 = 0 THEN 'scattered scattered'
        ELSE 'scattered filler words here'
    END || ' doc' || i
FROM generate_series(1, 1000) i;

CREATE INDEX bmw_scattered_idx ON bmw_scattered USING bm25(content)
    WITH (text_config='english');

-- The top-10 should include docs 100,200,300,400,500,600,700,800,900,1000
-- These are spread across 8 different blocks (1000/128 = ~8 blocks)
SELECT id, content <@> 'scattered'::bm25query as score
FROM bmw_scattered
ORDER BY content <@> 'scattered'::bm25query LIMIT 10;

-- Validation: Verify top 10 includes the high-tf docs from different blocks
WITH top10 AS (
    SELECT id FROM bmw_scattered
    ORDER BY content <@> 'scattered'::bm25query LIMIT 10
)
SELECT 'scattered-blocks' as test,
    CASE WHEN (SELECT COUNT(*) FROM top10 WHERE id IN (100,200,300,400,500,600,700,800,900,1000)) >= 8
         THEN 'PASS' ELSE 'FAIL' END as result;

-- Also validate with exhaustive comparison
WITH bmw AS (
    SELECT id, content <@> 'scattered'::bm25query as score
    FROM bmw_scattered
    ORDER BY content <@> 'scattered'::bm25query LIMIT 10
),
exhaustive AS (
    SELECT id, score FROM (
        SELECT id, content <@> 'scattered'::bm25query as score
        FROM bmw_scattered
        ORDER BY content <@> 'scattered'::bm25query
    ) x LIMIT 10
)
SELECT 'scattered-equals-exhaustive' as test,
    CASE WHEN COUNT(*) = 0 THEN 'PASS' ELSE 'FAIL' END as result
FROM (SELECT * FROM bmw EXCEPT SELECT * FROM exhaustive) diff;

DROP TABLE bmw_scattered;

-- ============================================================
-- SECTION 16: Multi-term with scattered high-scorers
-- ============================================================
-- Tests that multi-term BMW also works with scattered results

CREATE TABLE bmw_multi_scattered (id SERIAL PRIMARY KEY, content TEXT);

INSERT INTO bmw_multi_scattered (content)
SELECT
    CASE
        WHEN i % 100 = 0 THEN 'alpha alpha alpha beta beta gamma'
        WHEN i % 50 = 0 THEN 'alpha alpha beta beta'
        WHEN i % 10 = 0 THEN 'alpha beta'
        ELSE 'alpha filler content'
    END || ' doc' || i
FROM generate_series(1, 1000) i;

CREATE INDEX bmw_multi_scattered_idx ON bmw_multi_scattered USING bm25(content)
    WITH (text_config='english');

-- Multi-term query - top results should come from scattered positions
WITH bmw AS (
    SELECT id, content <@> 'alpha beta gamma'::bm25query as score
    FROM bmw_multi_scattered
    ORDER BY content <@> 'alpha beta gamma'::bm25query LIMIT 20
),
exhaustive AS (
    SELECT id, score FROM (
        SELECT id, content <@> 'alpha beta gamma'::bm25query as score
        FROM bmw_multi_scattered
        ORDER BY content <@> 'alpha beta gamma'::bm25query
    ) x LIMIT 20
)
SELECT 'multiterm-scattered' as test,
    CASE WHEN COUNT(*) = 0 THEN 'PASS' ELSE 'FAIL' END as result
FROM (SELECT * FROM bmw EXCEPT SELECT * FROM exhaustive) diff;

DROP TABLE bmw_multi_scattered;

-- ============================================================
-- SECTION 17: Multiple segments
-- ============================================================

CREATE TABLE bmw_multiseg (id SERIAL PRIMARY KEY, content TEXT);

-- Batch 1 -> segment 1 (via CREATE INDEX)
INSERT INTO bmw_multiseg (content)
SELECT 'first segment batch ' || i || ' targetword'
FROM generate_series(1, 300) i;

CREATE INDEX bmw_multiseg_idx ON bmw_multiseg USING bm25(content)
    WITH (text_config='english');

-- Batch 2 -> segment 2
INSERT INTO bmw_multiseg (content)
SELECT 'second segment batch ' || i || ' targetword targetword'
FROM generate_series(301, 600) i;

SELECT bm25_spill_index('bmw_multiseg_idx');

-- Batch 3 -> memtable (not spilled)
INSERT INTO bmw_multiseg (content)
SELECT 'third batch ' || i || ' targetword targetword targetword'
FROM generate_series(601, 700) i;

-- Test: Should find best results across all segments + memtable
-- Third batch has highest tf, should rank first
SELECT id, content <@> 'targetword'::bm25query as score
FROM bmw_multiseg
ORDER BY content <@> 'targetword'::bm25query LIMIT 10;

-- Verify: Results should include docs from batch 3 (id > 600) at top

-- Also verify total count is correct (use to_bm25query for count)
SELECT COUNT(*) FROM (
    SELECT 1 FROM bmw_multiseg
    ORDER BY content <@> to_bm25query('targetword', 'bmw_multiseg_idx')
) sub;

DROP TABLE bmw_multiseg;

-- ============================================================
-- SECTION 18: Partial last block
-- ============================================================
-- Test with 150 docs = 1 full block (128) + 1 partial block (22)
-- This tests off-by-one errors in block iteration

CREATE TABLE bmw_partial (id SERIAL PRIMARY KEY, content TEXT);

-- 150 docs with varying tf to create score diversity
INSERT INTO bmw_partial (content)
SELECT
    CASE
        WHEN i <= 5 THEN 'partial partial partial partial'  -- tf=4, in block 0
        WHEN i = 130 THEN 'partial partial partial'         -- tf=3, in partial block 1
        WHEN i = 145 THEN 'partial partial partial partial partial'  -- tf=5, in partial block 1
        ELSE 'partial filler doc' || i
    END
FROM generate_series(1, 150) i;

CREATE INDEX bmw_partial_idx ON bmw_partial USING bm25(content)
    WITH (text_config='english');

-- Test: Should find high-tf docs from BOTH blocks
-- Doc 145 (tf=5) should be #1, docs 1-5 (tf=4) should follow
SELECT validate_bm25_scoring('bmw_partial', 'content', 'bmw_partial_idx',
    'partial', 'english', 1.2, 0.75) as partial_block_valid;

-- Verify doc 145 is top result (highest tf in partial block)
SELECT 'partial-block-top' as test,
    CASE WHEN (SELECT id FROM bmw_partial
               ORDER BY content <@> to_bm25query('partial', 'bmw_partial_idx') LIMIT 1) = 145
         THEN 'PASS' ELSE 'FAIL' END as result;

DROP TABLE bmw_partial;

-- ============================================================
-- SECTION 19: Term only in memtable (not in segments)
-- ============================================================
-- Tests the case where segment iterators return "not found"
-- but memtable has data for the term

CREATE TABLE bmw_memonly (id SERIAL PRIMARY KEY, content TEXT);

-- Insert docs that will go to segment (common term)
INSERT INTO bmw_memonly (content)
SELECT 'segment content common word doc' || i
FROM generate_series(1, 200) i;

CREATE INDEX bmw_memonly_idx ON bmw_memonly USING bm25(content)
    WITH (text_config='english');

-- Force spill
SELECT bm25_spill_index('bmw_memonly_idx');

-- Now insert docs with a NEW term that only exists in memtable
INSERT INTO bmw_memonly (content) VALUES
    ('uniquememterm uniquememterm uniquememterm'),  -- tf=3
    ('uniquememterm uniquememterm'),                -- tf=2
    ('uniquememterm');                              -- tf=1


-- Test: Query for memtable-only term should work
SELECT id, content <@> 'uniquememterm'::bm25query as score
FROM bmw_memonly
ORDER BY content <@> 'uniquememterm'::bm25query LIMIT 5;

-- Verify: Should return exactly 3 docs, in tf order (201, 202, 203)
SELECT 'memtable-only-term' as test,
    CASE WHEN (SELECT COUNT(*) FROM (
                SELECT 1 FROM bmw_memonly
                ORDER BY content <@> to_bm25query('uniquememterm', 'bmw_memonly_idx')
           ) sub) = 3
         THEN 'PASS' ELSE 'FAIL' END as result;

-- Test: Multi-term with one term in segment, one in memtable only
SELECT id, content <@> 'common uniquememterm'::bm25query as score
FROM bmw_memonly
ORDER BY content <@> 'common uniquememterm'::bm25query LIMIT 5;

DROP TABLE bmw_memonly;

-- ============================================================
-- SECTION 20: Sparse posting lists (few postings per block)
-- ============================================================
-- When a term has very few postings spread across many doc IDs,
-- each "block" may have only 1-2 postings. This tests block-max
-- effectiveness when block_max ≈ actual score.

CREATE TABLE bmw_sparse (id SERIAL PRIMARY KEY, content TEXT);

-- Create 500 docs where only every 50th doc has the target term
-- This creates ~10 postings spread across what would be 4 blocks
INSERT INTO bmw_sparse (content)
SELECT
    CASE
        WHEN i % 50 = 0 THEN 'sparse rare term here doc' || i
        ELSE 'common filler words only doc' || i
    END
FROM generate_series(1, 500) i;

CREATE INDEX bmw_sparse_idx ON bmw_sparse USING bm25(content)
    WITH (text_config='english');

-- Test: Should find all 10 sparse docs
SELECT 'sparse-count' as test,
    CASE WHEN (SELECT COUNT(*) FROM (
                SELECT 1 FROM bmw_sparse
                ORDER BY content <@> to_bm25query('sparse', 'bmw_sparse_idx')
           ) sub) = 10
         THEN 'PASS' ELSE 'FAIL' END as result;

-- Test: BMW should match exhaustive for sparse terms
WITH bmw AS (
    SELECT id, content <@> 'sparse'::bm25query as score
    FROM bmw_sparse
    ORDER BY content <@> 'sparse'::bm25query LIMIT 10
),
exhaustive AS (
    SELECT id, score FROM (
        SELECT id, content <@> 'sparse'::bm25query as score
        FROM bmw_sparse
        ORDER BY content <@> 'sparse'::bm25query
    ) x LIMIT 10
)
SELECT 'sparse-equals-exhaustive' as test,
    CASE WHEN COUNT(*) = 0 THEN 'PASS' ELSE 'FAIL' END as result
FROM (SELECT * FROM bmw EXCEPT SELECT * FROM exhaustive) diff;

DROP TABLE bmw_sparse;

-- ============================================================
-- SECTION 21: Multi-term with different block structures
-- ============================================================
-- Term A has many postings (many blocks), term B has few (1 block)
-- Tests WAND traversal when iterators have very different lengths

CREATE TABLE bmw_asymmetric (id SERIAL PRIMARY KEY, content TEXT);

-- 500 docs: "common" in all, "rare" in only 5 specific docs
INSERT INTO bmw_asymmetric (content)
SELECT
    CASE
        WHEN i IN (50, 150, 250, 350, 450) THEN 'common rare both terms doc' || i
        ELSE 'common only single term doc' || i
    END
FROM generate_series(1, 500) i;

CREATE INDEX bmw_asymmetric_idx ON bmw_asymmetric USING bm25(content)
    WITH (text_config='english');

-- Test: "common rare" should find only the 5 docs with both terms at top
-- (they have higher combined score than single-term docs)
SELECT validate_bm25_scoring('bmw_asymmetric', 'content', 'bmw_asymmetric_idx',
    'common rare', 'english', 1.2, 0.75) as asymmetric_valid;

-- Verify top 5 are the dual-term docs (they should have best scores)
WITH top5 AS (
    SELECT id FROM bmw_asymmetric
    ORDER BY content <@> 'common rare'::bm25query LIMIT 5
)
SELECT 'asymmetric-top5' as test,
    CASE WHEN (SELECT COUNT(*) FROM top5
               WHERE id IN (50, 150, 250, 350, 450)) = 5
         THEN 'PASS' ELSE 'FAIL' END as result;

DROP TABLE bmw_asymmetric;

-- ============================================================
-- SECTION 22: Threshold exactly equals block_max
-- ============================================================
-- Create scenario where block_max score equals the threshold exactly
-- Tests boundary condition in score < threshold vs score <= threshold

CREATE TABLE bmw_threshold (id SERIAL PRIMARY KEY, content TEXT);

-- Create docs with IDENTICAL scores to force threshold edge case
-- All docs have tf=1 and same length -> identical BM25 scores
INSERT INTO bmw_threshold (content)
SELECT 'threshold test word' FROM generate_series(1, 200);

CREATE INDEX bmw_threshold_idx ON bmw_threshold USING bm25(content)
    WITH (text_config='english');

-- Test: With 200 identical-score docs, LIMIT 10 should return 10
-- and they should be ordered by CTID (id 1-10)
SELECT 'threshold-boundary' as test,
    CASE WHEN (SELECT COUNT(*) FROM (
        SELECT id FROM bmw_threshold
        ORDER BY content <@> to_bm25query('threshold', 'bmw_threshold_idx') LIMIT 10
    ) x) = 10
    THEN 'PASS' ELSE 'FAIL' END as result;

-- Verify CTID ordering for tied scores (should be ids 1-10)
SELECT 'threshold-tiebreak' as test,
    CASE WHEN (SELECT array_agg(id ORDER BY id) FROM (
        SELECT id FROM bmw_threshold
        ORDER BY content <@> to_bm25query('threshold', 'bmw_threshold_idx') LIMIT 10
    ) x) = ARRAY[1,2,3,4,5,6,7,8,9,10]
    THEN 'PASS' ELSE 'FAIL' END as result;

DROP TABLE bmw_threshold;

-- ============================================================
-- SECTION 23: All iterators exhaust simultaneously
-- ============================================================
-- Create a scenario where multiple term iterators all finish
-- at exactly the same document

CREATE TABLE bmw_simul (id SERIAL PRIMARY KEY, content TEXT);

-- 100 docs where all have both terms - iterators move in lockstep
INSERT INTO bmw_simul (content)
SELECT 'alpha beta both terms doc' || i FROM generate_series(1, 100) i;

-- Add one doc with only alpha at end
INSERT INTO bmw_simul (content) VALUES ('alpha only final');

CREATE INDEX bmw_simul_idx ON bmw_simul USING bm25(content)
    WITH (text_config='english');

-- Test: Should handle simultaneous exhaustion correctly
WITH bmw AS (
    SELECT id, content <@> 'alpha beta'::bm25query as score
    FROM bmw_simul
    ORDER BY content <@> 'alpha beta'::bm25query LIMIT 20
),
exhaustive AS (
    SELECT id, score FROM (
        SELECT id, content <@> 'alpha beta'::bm25query as score
        FROM bmw_simul
        ORDER BY content <@> 'alpha beta'::bm25query
    ) x LIMIT 20
)
SELECT 'simultaneous-exhaust' as test,
    CASE WHEN COUNT(*) = 0 THEN 'PASS' ELSE 'FAIL' END as result
FROM (SELECT * FROM bmw EXCEPT SELECT * FROM exhaustive) diff;

DROP TABLE bmw_simul;

-- ============================================================
-- SECTION 24: Document length variance within blocks
-- ============================================================
-- When a block contains a mix of very short and very long docs,
-- the block-max upper bound must use the shortest doc's length
-- (lowest fieldnorm) to produce a valid BM25 upper bound.
-- This test catches bugs where the longest doc's fieldnorm is
-- used instead, making the upper bound too tight and causing
-- BMW to incorrectly skip blocks with high-scoring short docs.

CREATE TABLE bmw_length_variance (id SERIAL PRIMARY KEY, content TEXT);

-- Create 500 docs with high length variance within each 128-doc block.
-- Short docs (3 words) are interleaved with long docs (100+ words).
-- A rare term "unicorn" appears only in a few short docs, scattered
-- across blocks. These short docs should score highest for "unicorn"
-- because BM25 penalizes longer documents.
INSERT INTO bmw_length_variance (content)
SELECT
    CASE
        -- Rare term in short docs at positions that span multiple blocks
        WHEN i IN (10, 140, 270, 400) THEN 'unicorn magic sparkle doc' || i
        -- Long docs with padding (pushes block fieldnorm high)
        WHEN i % 3 = 0 THEN 'common words here doc' || i || ' ' || repeat('padding ', 100)
        -- Medium docs
        WHEN i % 3 = 1 THEN 'common words here with more content doc' || i
        -- Short docs without the rare term
        ELSE 'common words here doc' || i
    END
FROM generate_series(1, 500) i;

CREATE INDEX bmw_length_variance_idx ON bmw_length_variance USING bm25(content)
    WITH (text_config='english');

-- Single-term: BMW must match exhaustive for "unicorn"
WITH bmw AS (
    SELECT id, content <@> 'unicorn'::bm25query as score
    FROM bmw_length_variance
    ORDER BY content <@> 'unicorn'::bm25query LIMIT 10
),
exhaustive AS (
    SELECT id, score FROM (
        SELECT id, content <@> 'unicorn'::bm25query as score
        FROM bmw_length_variance
        ORDER BY content <@> 'unicorn'::bm25query
    ) x LIMIT 10
)
SELECT 'length-variance-single-term' as test,
    CASE WHEN COUNT(*) = 0 THEN 'PASS' ELSE 'FAIL' END as result
FROM (SELECT * FROM bmw EXCEPT SELECT * FROM exhaustive) diff;

-- Multi-term: "common unicorn" -- the rare "unicorn" term has high IDF,
-- so short docs with "unicorn" should dominate. BMW must not skip their
-- blocks just because long docs in the same block deflate the upper bound.

-- Verify the unicorn docs are top-4 for "common unicorn"
WITH top4 AS (
    SELECT id FROM bmw_length_variance
    ORDER BY content <@> 'common unicorn'::bm25query LIMIT 4
)
SELECT 'length-variance-top4' as test,
    CASE WHEN (SELECT COUNT(*) FROM top4
               WHERE id IN (10, 140, 270, 400)) = 4
         THEN 'PASS' ELSE 'FAIL' END as result;

-- BMW vs exhaustive with enough LIMIT to avoid tie boundary
WITH bmw AS (
    SELECT id, content <@> 'common unicorn'::bm25query as score
    FROM bmw_length_variance
    ORDER BY content <@> 'common unicorn'::bm25query LIMIT 20
),
exhaustive AS (
    SELECT id, score FROM (
        SELECT id, content <@> 'common unicorn'::bm25query as score
        FROM bmw_length_variance
        ORDER BY content <@> 'common unicorn'::bm25query
    ) x LIMIT 20
)
SELECT 'length-variance-bmw-exhaustive' as test,
    CASE WHEN COUNT(*) = 0 THEN 'PASS' ELSE 'FAIL' END as result
FROM (SELECT * FROM bmw EXCEPT SELECT * FROM exhaustive) diff;

DROP TABLE bmw_length_variance;

-- ============================================================
-- Cleanup
-- ============================================================
DROP EXTENSION pg_textsearch CASCADE;
