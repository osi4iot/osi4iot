-- Aerodynamics Documents pg_textsearch Test - Real Cranfield Dataset
-- This test validates pg_textsearch implementation using a substantial subset of the Cranfield collection
-- Contains real aerodynamics documents from the Cranfield dataset for realistic testing
-- Tests both dataset loading and pg_textsearch scoring functionality with the <@> operator

-- Load pg_textsearch extension
CREATE EXTENSION IF NOT EXISTS pg_textsearch;

\set ECHO none
\i test/sql/validation.sql
\set ECHO all

-- Enable score logging for testing
SET pg_textsearch.log_scores = true;

\set ON_ERROR_STOP on
\echo 'Testing pg_textsearch with sample aerodynamics documents...'

-- Create tables for aerodynamics documents
CREATE TABLE aerodocs_documents (
    doc_id INTEGER PRIMARY KEY,
    title TEXT,
    author TEXT,
    bibliography TEXT,
    content TEXT,
    full_text TEXT GENERATED ALWAYS AS (
        COALESCE(title, '') || ' ' ||
        COALESCE(author, '') || ' ' ||
        COALESCE(content, '')
    ) STORED
);

CREATE TABLE cranfield_queries (
    query_id INTEGER PRIMARY KEY,
    query_text TEXT NOT NULL
);

-- Expected rankings table removed - we test against actual output

\echo 'Loading subset of Cranfield documents for testing...'

INSERT INTO aerodocs_documents (doc_id, title, author, content) VALUES
(1, 'experimental investigation of the aerodynamics of a wing in a slipstream .', 'brenckman,m.', 'experimental investigation of the aerodynamics of a wing in a slipstream . an experimental study of a wing in a propeller slipstream was made in order to determine the spanwise distribution of the lift increase due to slipstream at different angles of attack of the wing and at different free stream to slipstream velocity ratios .  the results were intended in part as an evaluation basis for different theoretical treatments of this problem . the comparative span loading curves, together with supporting evidence, showed that a substantial part of the lift increment produced by the slipstream was due to a /destalling/ or boundary-layer-control effect .  the integrated remaining lift increment, after subtracting this destalling lift, was found to agree well with a potential flow theory . an empirical evaluation of the destalling effects was made for the specific configuration of the experiment .'),
(2, 'simple shear flow past a flat plate in an incompressible fluid of small viscosity .', 'ting-yili', 'in the study of high-speed viscous flow past a two-dimensional body it is usually necessary to consider a curved shock wave emitting from the nose or leading edge of the body .  consequently, there exists an inviscid rotational flow region between the shock wave and the boundary layer .  such a situation arises, for instance, in the study of the hypersonic viscous flow past a flat plate .  the situation is somewhat different from prandtl''s classical boundary-layer problem . in prandtl''s original problem the inviscid free stream outside the boundary layer is irrotational while in a hypersonic boundary-layer problem the inviscid free stream must be considered as rotational .  the possible effects of vorticity have been recently discussed by ferri and libby .  in the present paper, the simple shear flow past a flat plate in a fluid of small viscosity is investigated .  it can be shown that this problem can again be treated by the boundary-layer approximation, the only novel feature being that the free stream has a constant vorticity .  the discussion here is restricted to two-dimensional incompressible steady flow .'),
(3, 'the boundary layer in simple shear flow past a flat plate .', 'm. b. glauert', 'the boundary-layer equations are presented for steady incompressible flow with no pressure gradient .'),
(4, 'approximate solutions of the incompressible laminar boundary layer equations for a plate in shear flow .', 'yen,k.t.', 'the two-dimensional steady boundary-layer problem for a flat plate in a shear flow of incompressible fluid is considered . solutions for the boundary- layer thickness, skin friction, and the velocity distribution in the boundary layer are obtained by the karman-pohlhausen technique .  comparison with the boundary layer of a uniform flow has also been made to show the effect of vorticity .'),
(5, 'one-dimensional transient heat conduction into a double-layer slab subjected to a linear heat input for a small time internal .', 'wasserman,b.', 'analytic solutions are presented for the transient heat conduction in composite slabs exposed at one surface to a triangular heat rate .  this type of heating rate may occur, for example, during aerodynamic heating .'),
(6, 'one-dimensional transient heat flow in a multilayer slab .', 'campbell,w.f.', 'in a recent contribution to the readers forum wassermann gave analytic solutions for the temperature in a double layer slab, with a triangular heat rate input at one face, insulated at the other, and with no thermal resistance at the interface .  his solutions were for the three particular cases.. i propose here to give the general solution to this problem, to indicate briefly how it is obtained using the method of reference 2, and to point out that the solutions given by wassermann are incomplete for times longer than the duration of the heat input .'),
(7, 'the effect of controlled three-dimensional roughness on boundary layer transition at supersonic speeds .', 'van driest,e.r. and mccauley,w.d.', 'experiments were performed in the 12-in. supersonic wind tunnel of the jet propulsion laboratory of the california institute of technology to investigate the effect of three-dimensional roughness elements (spheres) on boundary-layer transition on a tained at local mach numbers of 1.90, 2.71, and 3.67 by varying trip size, position, spacing, and reynolds number per inch . the results indicate that (1) transition from laminar to turbulent flow induced by three-dimensional roughness elements begins when the double row of spiral vortices trailing each element contaminates and breaks down the surrounding field of vorticity, (2) transition appears rather suddenly, becoming more violent with increasing roughness height relative to the boundary-layer thickness, (3) after the breakdown of the vorticity field, the strength of the spiral vortices may still persist in the sublayer of the ensuing turbulent flow, (4) lateral spacing of roughness elements has little effect upon the initial breakdown (contamination) of the laminar flow, and (5) the trip reynolds number where u and v are the velocity and kinematic viscosity at the outer edge of the boundary layer and k is roughness height, such that transition occurs at the roughness position, varies as the position reynolds number to the one-fourth power, viz., where x is trip position .'),
(8, 'measurements of the effect of two-dimensional and three-dimensional roughness elements on boundary layer transition .', 'klebanoff,p.s.', 'in his study of the effect of roughness on transition, h. l. dryden found, on the basis of available data, that the effect of a two-dimensional roughness element such as a /trip wire/ could be represented reasonably well in terms of a functional relation between and, where is the reynolds number of transition based on distance from the leading edge, is the height of the roughness element, and is the boundary-layer displacement thickness at the position of the element .  at his suggestion some additional data were obtained, primarily to extend the range to higher values of, during the course of an investigation of transition on a flat plate conducted at the national bureau of standards .  after the results on the two- dimensional roughness elements were obtained, it appeared to be desirable to see whether a row of three-dimensional roughness elements would behave in the same way .'),
(9, 'transition studies and skin friction measurements on an insulated flat plate at a mach number of 5.8 .', 'korkegi,r.h.', 'an investigation of transition and skin friction on an insulated flat plate, 5 by 26 in., was made in the galcit 5 by 5 in. hypersonic wind tunnel at a nominal mach number of 5.8 . the phosphorescent lacquer technique was used for transition detection and was found to be in good agreement with total-head rake measurements along the plate surface and pitot boundary- layer surveys .  it was found that the boundary layer was laminar at reynolds numbers of at least 5 x 10 .  transverse contamination caused by the turbulent boundary layer on the tunnel sidewall originated far downstream of the flat plate leading edge at reynolds numbers of 1.5 to 2 x 10, and spread at a uniform angle of 5 compared to 9 degree in low-speed flow . the effect of two-dimensional and local disturbances was investigated .  the technique of air injection into the boundary layer as a means of hastening transition was extensively used . although the onset of transition occurred at reynolds numbers as low as 10, a fully developed turbulent boundary layer was not obtained at reynolds numbers much below 2 x 10 regardless of the amount of air injected . a qualitative discussion of these results is given with emphasis on the possibility of a greater stability of the laminar boundary layer in hypersonic flow than at lower speeds . direct skin-friction measurements were made by means of the floating element technique, over a range of reynolds numbers verified as being laminar over the complete range .  with air injection, turbulent shear was obtained only for reynolds numbers greater than 2 x 10, this value being in good agreement with earlier results of this investigation .  the turbulent skin-friction coefficient was found to be approximately 0.40 of that for incompressible flow for a constant value of r, and 0.46 for an effective reynolds number between 5 and 6 x 10 .'),
(10, 'the theory of the impact tube at low pressure .', 'chambre,p.l. and schaaf,s.a.', 'a theoretical analysis has been made for an impact tube of the relation between free-stream mach number and the impact and free-stream pressures and densities for extremely low pressures . it is shown that the results differ appreciably from the corresponding continuum relations .');

-- Insert sample queries
INSERT INTO cranfield_queries (query_id, query_text) VALUES
(1, 'aerodynamic flow analysis'),
(2, 'boundary layer turbulent'),
(3, 'wing design optimization');

-- Expected rankings are now captured in the test's expected output file

-- Create pg_textsearch index for Cranfield documents with text_config
CREATE INDEX cranfield_tapir_idx ON aerodocs_documents USING bm25(full_text)
    WITH (text_config='english', k1=1.2, b=0.75);

\echo 'pg_textsearch index created. Running validation tests...'

-- Disable sequential scans to ensure index usage
SET enable_seqscan = off;

-- Test 0: Simple single-term validation
\echo 'Test 0: Single-term query validation'
SELECT
    doc_id,
    LEFT(title, 60) as title_preview,
    ROUND((full_text <@> 'aerodynamic')::numeric, 4) as score
FROM aerodocs_documents
ORDER BY full_text <@> 'aerodynamic' ASC
LIMIT 3;

-- Validate single-term BM25 scoring
SELECT validate_bm25_scoring('aerodocs_documents', 'full_text', 'cranfield_tapir_idx', 'aerodynamic', 'english', 1.2, 0.75) as aerodynamic_valid;

-- Test 1: Basic search functionality
\echo 'Test 1: Basic search with <@> operator'
SELECT
    doc_id,
    LEFT(title, 60) as title_preview,
    ROUND((full_text <@> 'aerodynamic flow')::numeric, 4) as score
FROM aerodocs_documents
ORDER BY full_text <@> 'aerodynamic flow' ASC
LIMIT 5;

-- Test 2: Multi-term search
\echo 'Test 2: Multi-term search'
SELECT
    doc_id,
    LEFT(title, 60) as title_preview,
    ROUND((full_text <@> 'boundary layer turbulent')::numeric, 4) as score
FROM aerodocs_documents
ORDER BY full_text <@> 'boundary layer turbulent' ASC
LIMIT 5;

-- Test 3: Top-10 results for first query
\echo 'Test 3: Top-10 results for first query'
WITH pgts_results AS (
    SELECT
        doc_id,
        ROUND((full_text <@> 'aerodynamic flow analysis')::numeric, 4) as pgts_score,
        ROW_NUMBER() OVER (ORDER BY full_text <@> 'aerodynamic flow analysis' ASC) as pgts_rank
    FROM aerodocs_documents
)
SELECT
    br.doc_id,
    br.pgts_rank,
    br.pgts_score as score,
    LEFT(d.title, 50) as title_preview
FROM pgts_results br
JOIN aerodocs_documents d ON br.doc_id = d.doc_id
WHERE br.pgts_rank <= 10
ORDER BY br.pgts_rank;

-- Test 4: Performance test with multiple queries
\echo 'Test 4: Performance test with top-k search'
SELECT
    q.query_id,
    LEFT(q.query_text, 40) || '...' as query_preview,
    COUNT(d.doc_id) as total_docs,
    COUNT(CASE WHEN d.full_text <@> to_bm25query(q.query_text, 'cranfield_tapir_idx') < 0 THEN 1 END) as matching_docs
FROM cranfield_queries q
CROSS JOIN aerodocs_documents d
WHERE q.query_id <= 5  -- Test first 5 queries for performance
GROUP BY q.query_id, q.query_text
ORDER BY q.query_id;

-- Test 5: Index usage verification
\echo 'Test 5: Verify index usage with EXPLAIN'
SET jit = off;
EXPLAIN (COSTS OFF)
SELECT doc_id, ROUND((full_text <@> 'supersonic aircraft design')::numeric, 4)
    as score
FROM aerodocs_documents
ORDER BY full_text <@> 'supersonic aircraft design' ASC
LIMIT 10;

-- Reset settings
SET enable_seqscan = on;

\echo 'Cranfield pg_textsearch validation completed successfully.'
\echo 'All tests demonstrate proper pg_textsearch functionality with the <@> operator.'

-- Clean up
DROP TABLE aerodocs_documents CASCADE;
DROP TABLE cranfield_queries CASCADE;
DROP EXTENSION pg_textsearch CASCADE;
