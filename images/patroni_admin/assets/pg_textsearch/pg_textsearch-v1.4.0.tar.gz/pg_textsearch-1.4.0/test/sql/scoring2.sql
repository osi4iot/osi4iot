-- Test case: scoring2
-- Generated BM25 test with 5 documents and 4 queries
-- Testing both bulk build and incremental build modes
CREATE EXTENSION IF NOT EXISTS pg_textsearch;

\set ECHO none
\i test/sql/validation.sql
\set ECHO all

SET pg_textsearch.log_scores = true;
SET enable_seqscan = off;

-- MODE 1: Bulk build (insert data, then create index)
CREATE TABLE scoring2_bulk (
    id SERIAL PRIMARY KEY,
    content TEXT
);

-- Insert test documents
INSERT INTO scoring2_bulk (content) VALUES ('hello world');
INSERT INTO scoring2_bulk (content) VALUES ('goodbye world');
INSERT INTO scoring2_bulk (content) VALUES ('hello goodbye');
INSERT INTO scoring2_bulk (content) VALUES ('world domination');
INSERT INTO scoring2_bulk (content) VALUES ('hello');

-- Create index after data insertion (bulk build)
CREATE INDEX scoring2_bulk_idx ON scoring2_bulk USING bm25(content)
  WITH (text_config='english', k1=1.2, b=0.75);

-- Bulk mode query 1: 'hello'
SELECT id, content, ROUND((content <@> 'hello')::numeric, 4) as score
FROM scoring2_bulk
ORDER BY content <@> 'hello', id;

-- Validate BM25 scoring for 'hello'
SELECT validate_bm25_scoring('scoring2_bulk', 'content', 'scoring2_bulk_idx', 'hello', 'english', 1.2, 0.75) as hello_bulk_valid;

-- Bulk mode query 2: 'world'
SELECT id, content, ROUND((content <@> 'world')::numeric, 4) as score
FROM scoring2_bulk
ORDER BY content <@> 'world', id;

-- Validate BM25 scoring for 'world'
SELECT validate_bm25_scoring('scoring2_bulk', 'content', 'scoring2_bulk_idx', 'world', 'english', 1.2, 0.75) as world_bulk_valid;

-- Bulk mode query 3: 'goodbye'
SELECT id, content, ROUND((content <@> 'goodbye')::numeric, 4) as score
FROM scoring2_bulk
ORDER BY content <@> 'goodbye', id;

-- Validate BM25 scoring for 'goodbye'
SELECT validate_bm25_scoring('scoring2_bulk', 'content', 'scoring2_bulk_idx', 'goodbye', 'english', 1.2, 0.75) as goodbye_bulk_valid;

-- Bulk mode query 4: 'domination'
SELECT id, content, ROUND((content <@> 'domination')::numeric, 4) as score
FROM scoring2_bulk
ORDER BY content <@> 'domination', id;

-- Validate BM25 scoring for 'domination'
SELECT validate_bm25_scoring('scoring2_bulk', 'content', 'scoring2_bulk_idx', 'domination', 'english', 1.2, 0.75) as domination_bulk_valid;

-- MODE 2: Incremental build (create index, then insert data)
CREATE TABLE scoring2_incr (
    id SERIAL PRIMARY KEY,
    content TEXT
);

-- Create index before data insertion (incremental build)
CREATE INDEX scoring2_incr_idx ON scoring2_incr USING bm25(content)
  WITH (text_config='english', k1=1.2, b=0.75);

-- Insert test documents incrementally
INSERT INTO scoring2_incr (content) VALUES ('hello world');
INSERT INTO scoring2_incr (content) VALUES ('goodbye world');
INSERT INTO scoring2_incr (content) VALUES ('hello goodbye');
INSERT INTO scoring2_incr (content) VALUES ('world domination');
INSERT INTO scoring2_incr (content) VALUES ('hello');

-- Incremental mode query 1: 'hello'
SELECT id, content, ROUND((content <@> 'hello')::numeric, 4) as score
FROM scoring2_incr
ORDER BY content <@> 'hello', id;

-- Validate BM25 scoring for 'hello' (incremental)
SELECT validate_bm25_scoring('scoring2_incr', 'content', 'scoring2_incr_idx', 'hello', 'english', 1.2, 0.75) as hello_incr_valid;

-- Incremental mode query 2: 'world'
SELECT id, content, ROUND((content <@> 'world')::numeric, 4) as score
FROM scoring2_incr
ORDER BY content <@> 'world', id;

-- Validate BM25 scoring for 'world' (incremental)
SELECT validate_bm25_scoring('scoring2_incr', 'content', 'scoring2_incr_idx', 'world', 'english', 1.2, 0.75) as world_incr_valid;

-- Incremental mode query 3: 'goodbye'
SELECT id, content, ROUND((content <@> 'goodbye')::numeric, 4) as score
FROM scoring2_incr
ORDER BY content <@> 'goodbye', id;

-- Validate BM25 scoring for 'goodbye' (incremental)
SELECT validate_bm25_scoring('scoring2_incr', 'content', 'scoring2_incr_idx', 'goodbye', 'english', 1.2, 0.75) as goodbye_incr_valid;

-- Incremental mode query 4: 'domination'
SELECT id, content, ROUND((content <@> 'domination')::numeric, 4) as score
FROM scoring2_incr
ORDER BY content <@> 'domination', id;

-- Validate BM25 scoring for 'domination' (incremental)
SELECT validate_bm25_scoring('scoring2_incr', 'content', 'scoring2_incr_idx', 'domination', 'english', 1.2, 0.75) as domination_incr_valid;

-- Cleanup
DROP TABLE scoring2_bulk CASCADE;
DROP TABLE scoring2_incr CASCADE;
DROP EXTENSION pg_textsearch CASCADE;
